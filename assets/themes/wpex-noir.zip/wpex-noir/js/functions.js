 /**
 * Theme functions
 * Initialize all scripts and adds custom js
 *
 * @since 1.0.0
 *
 */

( function( $ ) {

	'use strict';

	var wpexFunctions = {

		/**
		 * Define cache var
		 *
		 * @since 1.0.0
		 */
		cache: {},

		/**
		 * Main Function
		 *
		 * @since 1.0.0
		 */
		init: function() {
			this.cacheElements();
			this.bindEvents();
		},

		/**
		 * Cache Elements
		 *
		 * @since 1.0.0
		 */
		cacheElements: function() {
			this.cache = {
				$window   : $( window ),
				$document : $( document ),
				$body     : $( 'body' ),
				$isMobile : false
			};
		},

		/**
		 * Bind Events
		 *
		 * @since 1.0.0
		 */
		bindEvents: function() {

			// Get sef
			var self = this;

			// Check if touch is supported
			self.cache.$isTouch = ( ( 'ontouchstart' in window ) || ( navigator.msMaxTouchPoints > 0 ) );

			// Run on document ready
			self.cache.$document.on( 'ready', function() {
				self.mobileCheck();
				self.coreFunctions();
				self.scrollTop();
				self.lightbox();
				self.mobileMenu();
				self.offCanvasMenu();
				self.wooTweaks();
			} );

			// Run on Window Load
			self.cache.$window.on( 'load', function() {
				self.cache.$body.addClass( 'wpex-site-loaded' );
				self.lightSliders();
				//self.nextPostPopup();
			} );

		},

		/**
		 * Mobile Check
		 *
		 * @since 2.1.0
		 */
		mobileCheck: function() {
			if ( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test( navigator.userAgent ) ) {
				this.cache.$body.addClass( 'wpex-is-mobile-device' );
				this.cache.$isMobile = true;
				return true;
			}
		},

		/**
		 * Main theme functions
		 *
		 * @since 1.0.0
		 */
		coreFunctions: function() {

			var self = this;

			// Featured image loaded
			var $featured_post = $( '.wpex-featured-entry' );
			if ( $featured_post.length ) {
				$featured_post.imagesLoaded( function() {
					$featured_post.addClass( 'wpex-images-loaded' );
				} );
			}
		   
			// Add class to last pingback for styling purposes
			$( ".commentlist li.pingback" ).last().addClass( 'last' );

			// Touch event for dropdowns
			$( '.wpex-dropdown-menu li.menu-item-has-children' ).on( 'touchstart', function( event ) {
				$( this ).toggleClass( 'wpex-touched' );
			} );

			// Responsive videos
			$( '.wpex-responsive-embed' ).fitVids( {
				ignore: '.wpex-fitvids-ignore'
			} );
			$( '.wpex-responsive-embed' ).addClass( 'wpex-show' );

			// Social share scroll to
			$( '.wpex-post-share .wpex-comment a, .single .comments-link' ).click( function() {
				var $target = $( '#comments' );
				if ( $target.length ) {
					$( 'html,body' ).animate({
						scrollTop: $target.offset().top - 30
					}, 1000 );
			      }
				return false;
			} );

			// Equal heights
            $( '.wpex-row' ).wpexEqualHeights( {
                children: '.wpex-eq-height'
            } );

		},

		/**
		 * Off-Canvas Menu
		 *
		 * @since 1.0.0
		 */
		offCanvasMenu: function() {

			$( '.wpex-topbar-ofcanvas-toggle a' ).click( function() {
				var $offCanvasMenu = $( '.wpex-off-canvas-menu' );
				if ( $offCanvasMenu.length ) {
					$( 'body' ).toggleClass( 'wpex-shift-wrap' );
					$offCanvasMenu.toggleClass( 'wpex-active' );
				}
				return false;
			} );

			// Close on toggle click
			$( '.wpex-off-canvas-menu-close' ).on( 'click', function( event ) {
				$( '.wpex-off-canvas-menu' ).removeClass( 'wpex-active' );
				$( 'body' ).removeClass( 'wpex-shift-wrap' );
				return false;
			} );

			// Close on doc click
			$( document ).on( 'click', function( event ) {
				if ( ! $( event.target ).closest( '.wpex-off-canvas-menu' ).length ) {
					$( '.wpex-off-canvas-menu' ).removeClass( 'wpex-active' );
					$( 'body' ).removeClass( 'wpex-shift-wrap' );
				}
			} );

		},

		/**
		 * Mobile menu
		 *
		 * Custom code by WPExplorer.com - do not steal !!!
		 *
		 * @since 1.0.0
		 */
		mobileMenu: function() {

			self = this;

			// Site nav
			var $siteNav = $( '.wpex-site-nav' );

			// No site nav
			if ( ! $siteNav.length ) {
				return;
			}

			// Prepend Mobile menu
			$siteNav.after( '<nav class="wpex-mobile-nav"></nav>' );

			// Nav content
			if ( $( '.wpex-mobile-menu-alt' ).length ) {
				var $menuContainer = $( '.wpex-mobile-menu-alt .wpex-dropdown-menu' );
			} else {
				var $menuContainer = $siteNav.find( '.wpex-dropdown-menu' );
			}

			// Return if no nav
			if ( ! $menuContainer.length ) {
				return;
			}

			// Grab all content from menu
			var $menuContents = $menuContainer.html();

			// Get mobile nav object
			var $mobileNav = $( '.wpex-mobile-nav' );

			// Add all content to mobile nav
			$mobileNav.html( '<ul class="wpex-mobile-nav-ul wpex-container">' + $menuContents + '</ul>' );

			// Declare mobile nav ul
			var $mobileNavUl = $( '.wpex-mobile-nav-ul' );

			// Remove all classes inside prepended nav
			$( '.wpex-mobile-nav-ul, .wpex-mobile-nav-ul *' ).children().each(function() {
				var attributes = this.attributes;
				$( this ).removeAttr( 'style' );
			} );

			// Declare vars
			var $mobileNavToggle = $( '.wpex-mobile-nav-toggle' ),
				$mobileNavIcon   = $( '.wpex-mobile-nav-toggle-icon' ),
				$mobileNavText   = $( '.wpex-mobile-nav-toggle-text' );

			// Main toggle
			$mobileNavToggle.on( self.cache.$isMobile ? 'touchstart' : 'click', function() {
				if ( $mobileNav.hasClass( 'wpex-visible' ) ) {
					$mobileNav.removeClass( 'wpex-visible' );
					$mobileNavText.text( wpexLocalize.mobileMenuOpen );
					$mobileNavIcon.addClass( 'fa-bars' );
					$mobileNavIcon.removeClass( 'fa-times' );
				} else {
					$mobileNav.addClass( 'wpex-visible' );
					$mobileNavText.text( wpexLocalize.mobileMenuClose );
					$mobileNavIcon.addClass( 'fa-times' );
					$mobileNavIcon.removeClass( 'fa-bars' );
				}
				return false; // Better support for theme customizer
			} );

			// Close on orientation change
			$( window ).on( 'orientationchange', function() {
				if ( $mobileNav.hasClass( 'wpex-visible' ) ) {
					$mobileNav.hide();
					$mobileNavIcon.removeClass( 'fa-times' );
					$mobileNavIcon.addClass( 'fa-bars' );
					$mobileNavText.text( wpexLocalize.mobileMenuOpen );
				}
			} );

			// All items with dropdowns
			var $mobileNavSubMenuParents = $mobileNavUl.find( 'li.menu-item-has-children' );

			// Add plus icons to menu items with children
			$mobileNavSubMenuParents.each( function() {
				$( this ).children( 'a' ).append( '<span class="wpex-mobile-nav-plus-icon fa fa-plus"></span>' );
			} );

			// Add toggle click event
			$mobileNavUl.find( 'li.menu-item-has-children > a' ).on( self.cache.$isMobile ? 'touchstart' : 'click', function( ) {

				// Define toggle vars
				var $toggleParentLi = $( this ).parent( 'li' ),
					$allParentLis   = $toggleParentLi.parents( 'li' ),
					$dropdown       = $toggleParentLi.children( 'ul' );

				// Toogle items
				if ( ! $toggleParentLi.hasClass( 'wpex-active' ) ) {
					$mobileNavSubMenuParents.not( $allParentLis ).removeClass( 'wpex-active' ).children( 'ul' ).removeClass( 'wpex-visible' );
					$toggleParentLi.addClass( 'wpex-active' ).children( 'ul' ).addClass( 'wpex-visible' );
				} else {
					$toggleParentLi.removeClass( 'wpex-active' ).children( 'ul' ).removeClass( 'wpex-visible' );
				}

				// Return false
				return false;

			} );


		},

		/**
		 * Scroll top function
		 *
		 * @since 1.0.0
		 */
		scrollTop: function() {

			var $scrollTopLink = $( 'a.wpex-site-scroll-top' );

			this.cache.$window.scroll(function () {
				if ( $( this ).scrollTop() > 100 ) {
					$scrollTopLink.addClass( 'show' );
				} else {
					$scrollTopLink.removeClass( 'show' );
				}
			} );

			$scrollTopLink.on( 'click', function() {
				$( 'html, body' ).animate( {
					scrollTop : 0
				}, 400 );
				return false;
			} );

		},

		/**
		 * Post Slider
		 *
		 * @since 1.0.0
		 */
		lightSliders: function() {
			
			if ( $.fn.lightSlider === undefined ) {
				return;
			}
 
			// Post Slider
			var $slider = $( '.wpex-post-slider' );

			if ( $slider.length !== 0 ) {

				$slider.each( function() {

					var $this = $( this );

					$this.show();

					$this.lightSlider( {
						mode: 'fade',
						auto: false,
						speed: 500,
						adaptiveHeight: true,
						item: 1,
						slideMargin: 0,
						pager: false,
						loop: true,
						rtl: wpexLocalize.isRTL,
						prevHtml: '<span class="fa fa-angle-left"></span>',
						nextHtml: '<span class="fa fa-angle-right"></span>',
						onBeforeStart: function( el ) {
							$( '.slider-first-image-holder, .slider-preloader' ).hide();
						}
					} );

				} );

			}

			// Shop carousel
			var $shopCarouselOuter = $( '.wpex-shop-carousel-outer' );

			if ( $shopCarouselOuter.length !== 0 ) {

				$shopCarouselOuter.show();

				$( '.wpex-shop-carousel' ).lightSlider( {
					auto        : false,
					item        : parseInt( wpexShopCarousel.columns ),
					slideMove   : parseInt( wpexShopCarousel.columns ),
					prevHtml    : '<span class="fa fa-angle-left"></span>',
					nextHtml    : '<span class="fa fa-angle-right"></span>',
					pager       : true,
					controls    : false,
					rtl         : wpexLocalize.isRTL,
					slideMargin : parseInt( wpexShopCarousel.margin ),
					responsive  : [
						{
							breakpoint : 956,
							settings   : {
								item        : 4,
								slideMove   : 4,
								slideMargin : 20,
							  }
						},
						{
							breakpoint : 800,
							settings   : {
								item        : 3,
								slideMove   : 3,
								slideMargin : 20,
							  }
						},
						{
							breakpoint : 480,
							settings   : {
								item        : 2,
								slideMove   : 2,
								slideMargin : 10,
							  }
						}
					]
				} );

			}

		},

		/**
		 * Lightbox
		 *
		 * @since 1.0.0
		 */
		lightbox: function() {

			if ( $.fn.magnificPopup != undefined ) {

				// Gallery lightbox
				$( '.wpex-lightbox-gallery, .woocommerce .images' ).each( function() {
					$( this ).magnificPopup( {
						delegate    : 'a.wpex-lightbox-item',
						type        : 'image',
						gallery     : {
							enabled : true
						}
					} );
				} );

				if ( wpexLocalize.wpGalleryLightbox == true ) {

					$( '.wpex-entry .gallery' ).each( function() {

						// Check first item and see if it's linking to an image if so add lightbox
						var firstItemHref = $( this ).find( '.gallery-item a' ).first().attr( 'href' );
						if ( /\.(jpg|png|gif)$/.test( firstItemHref ) ) {
							$( this ).magnificPopup( {
								delegate    : '.gallery-item a',
								type        : 'image',
								gallery     : {
									enabled : true
								}
							} );
						}

					} );

				}

				// Auto add lightbox to entry images
				$( '.single-post .wpex-entry a:has(img)' ).each( function() {

					// Define this
					var $this = $( this );

					// Not for gallery
					if ( $this.parent().hasClass( 'gallery-icon' ) ) {
						return;
					}

					// Get data
					var $img  = $this.find( 'img' ),
						$src  = $img.attr( 'src' ),
						$ref  = $this.attr( 'href' ),
						$ext  = $ref.substr( ( $ref.lastIndexOf( '.' ) +1 ) );

					// Ad lightbox
					if ( 'png' == $ext || 'jpg' == $ext || 'jpeg' == $ext || 'gif' == $ext ) {
						$this.magnificPopup( {
							type    : 'image'
						} );
					}

				} );

			}

		},

		/**
		 * Next post popup
		 *
		 * @since 1.0.0
		 */
		nextPostPopup: function() {

			var $postArticle = $( '.wpex-post-article-box' );

			if ( $postArticle.length == 0 ) {
				return;
			}

			var $articleEndPosition = $postArticle.position().top+$postArticle.outerHeight()-$( '.wpex-site-header-wrap' ).outerHeight()-500;

			this.cache.$window.scroll( function() {

				if ( $( this ).scrollTop() >= $articleEndPosition ) {
					$( '.wpex-next-post-popup' ).removeClass( 'wpex-invisible' );
					$( '.wpex-next-post-popup' ).addClass( 'wpex-visible' );
				} else {
					$( '.wpex-next-post-popup' ).removeClass( 'wpex-visible' );
					$( '.wpex-next-post-popup' ).addClass( 'wpex-invisible' );
				}



			} );

		},

		/**
		 * WooCommerce Tweaks
		 *
		 * @since 1.0.0
		 */
		wooTweaks: function() {

			var self = this;

			var $cartToggle = $( '.wpex-menu-cart-toggle' );
			if ( ! $cartToggle.hasClass( 'toggle-disabled' ) ) {
				var $dropDown = $( '.wpex-cart-dropdown' );
				$cartToggle.click( function( event ) {
					$dropDown.toggleClass( 'wpex-invisible wpex-visible' );
					return false;
				} );
				$dropDown.click( function( event ) {
					event.stopPropagation();
				} );
				this.cache.$document.click( function() {
					$dropDown.removeClass( 'wpex-visible' );
					$dropDown.addClass( 'wpex-invisible' );
				} );
				$dropDown.bind( 'mousewheel DOMMouseScroll', function ( e ) {
					var e0    = e.originalEvent,
						delta = e0.wheelDelta || -e0.detail;
					this.scrollTop += ( delta < 0 ? 1 : -1 ) * 30;
					e.preventDefault();
				} );
			}

			$( '.wpex-shop-orderby-toggle' ).on( self.cache.$isTouch ? 'touchstart' : 'click', function( event ) {
				event.stopPropagation();
				$( this ).toggleClass( 'wpex-show-ul' );
			} );
			$( '.wpex-shop-orderby-toggle ul' ).on( self.cache.$isTouch ? 'touchstart' : 'click', function( event ) {
				event.stopPropagation();
			} );
			this.cache.$document.click( function() {
				$( '.wpex-shop-orderby-toggle' ).removeClass( 'wpex-show-ul' );
			} );

			var $productReviewsTitle = $( '.woocommerce-tabs #reviews #comments h2' );
			if ( $productReviewsTitle.length ) {
				$productReviewsTitle.html( wpexLocalize.productReviewsTitle );
			}

		},

	}; // END wpexFunctions

	// Get things going
	wpexFunctions.init();

} ) ( jQuery );