<?php
/**
 * The main header layout
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div class="wpex-site-header-wrap wpex-clr">

	<header class="wpex-site-header wpex-clr">

		<div class="wpex-site-branding wpex-container wpex-clr">

			<?php get_template_part( 'partials/header/logo' ); ?>

			<?php get_template_part( 'partials/header/blog-description' ); ?>

		</div><!-- .wpex-site-branding -->

	</header><!-- .wpex-site-header -->

	<?php get_template_part( 'partials/header/nav-main' ); ?>

</div><!-- .wpex-site-header-wrap -->