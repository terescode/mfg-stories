<?php
/**
 * The default template for displaying post entries.
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Base classes for entry
$classes = array( 'wpex-loop-entry', 'wpex-col', 'wpex-clr' );

// Counter
global $wpex_count;

// Check if embeds are allowed
$allow_embeds = wpex_get_theme_mod( 'entry_embeds', false );

// Check for media
$has_video = wpex_has_post_video();
$has_audio = wpex_has_post_audio();

// Left/right style
$entry_style = wpex_get_blog_entry_style();
$classes[] = 'wpex-loop-entry-style-'. $entry_style;
if ( 'left_right' == $entry_style && ( has_post_thumbnail() || ( $allow_embeds && ( $has_video || $has_audio ) ) ) ) {
	$classes[] = 'wpex-left-right';
}

// Entry columns
$columns   = ( 'grid' == $entry_style ) ? wpex_get_loop_columns() : '1';
$classes[] = 'wpex-col-'. $columns;
$classes[] = 'wpex-count-'. $wpex_count;

// Equal heights
if ( $columns > 1 && wpex_get_theme_mod( 'entry_equal_heights', false ) ) {
	$classes[] = 'wpex-has-eq-heights';
	$entry_equal_heights = true;
} else {
	$entry_equal_heights = false;
}

// Add column class
$classes[] = 'wpex-col-'. $columns; ?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>

	<div class="wpex-loop-entry-inner wpex-clr">

		<?php if ( $allow_embeds && $has_video ) : ?>

			<?php get_template_part( 'partials/entry/video' ); ?>

		<?php elseif ( $allow_embeds && $has_audio ) : ?>

			<?php get_template_part( 'partials/entry/audio' ); ?>

		<?php elseif ( wpex_get_theme_mod( 'entry_thumbnail', true )  && has_post_thumbnail() ) : ?>

			<?php get_template_part( 'partials/entry/thumbnail' ); ?>

		<?php endif; ?>

		<div class="wpex-loop-entry-content wpex-clr">

			<?php
			if ( $entry_equal_heights ) {
				echo '<div class="wpex-eq-height wpex-clr">';
			} ?>

			<?php
			// Display title
			get_template_part( 'partials/entry/title' ); ?>

			<?php
			// Display entry meta
			if ( wpex_get_theme_mod( 'entry_meta', true ) ) : ?>
				<?php get_template_part( 'partials/entry/meta' ); ?>
			<?php endif; ?>

			<?php
			// Display entry rating
			get_template_part( 'partials/entry/rating' ); ?>

			<?php
			// Display entry excerpt/content
			get_template_part( 'partials/entry/content' ); ?>

			<?php
			if ( $entry_equal_heights ) {
				echo '</div><!-- .wpex-eq-height -->';
			} ?>

			<?php
			// Entry Footer
			if ( wpex_get_theme_mod( 'entry_readmore', true )
				|| wpex_get_theme_mod( 'entry_social_share', true )
			) : ?>
				
				<div class="wpex-loop-entry-footer wpex-clr">

					<?php
					// Display entry readmore
					if ( wpex_get_theme_mod( 'entry_readmore', true ) ) : ?>
					 	<?php get_template_part( 'partials/entry/readmore' ); ?>
					<?php endif; ?>

				</div><!-- .wpex-loop-entry-footer -->

			<?php endif; ?>

		</div><!-- .wpex-loop-entry-content -->

	</div><!-- .wpex-boxed-container -->

</article><!-- .wpex-loop-entry -->

<?php
// Reset counter
if ( $wpex_count == $columns ) {
	$wpex_count = 0;
} ?>