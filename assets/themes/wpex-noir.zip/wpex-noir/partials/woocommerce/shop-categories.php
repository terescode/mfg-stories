<?php
/**
 * WooCommerce shop categories
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Display
$display = ( is_shop() && wpex_get_theme_mod( 'woo_shop_categories', true ) ) ? true : false;
$display = apply_filters( 'wpe_woo_shop_categories', $display );
if ( ! $display ) {
	return;
}

$columns = 4;

// Get cats
$args  = apply_filters( 'wpex_shop_categories_args', array(
	'orderby' => 'Name',
	'parent'  => 0,
) );
$terms = get_terms( 'product_cat', $args );

// If categories exist loop through them
if ( $terms ) : ?>

	<div class="wpex-shop-categories">

		<div class="wpex-row wpex-clr">

			<?php
			// Loop through terms
			$count = 0;
			foreach ( $terms as $term ) :
				$count ++;

				$name = $term->name;
				$thumbnail_id = get_woocommerce_term_meta( $term->term_id, 'thumbnail_id', true );
				if ( $thumbnail_id ) {
					$thumbnail = wp_get_attachment_image_src( $thumbnail_id, 'shop_catalog' );
					$thumbnail = isset( $thumbnail[0] ) ? $thumbnail[0] : '';
				}
				$thumbnail = $thumbnail_id ? $thumbnail : wc_placeholder_img_src();

				// Show category only if thumbnail exists
				if ( $thumbnail ) : ?>

					<div class="wpex-shop-categories-entry wpex-clr wpex-col wpex-col-<?php echo intval( $columns ); ?> wpex-count-<?php echo intval( $count ); ?>">
						<a href="<?php echo get_term_link( $term, 'product_cat' ); ?>" title="<?php echo esc_attr( $name ); ?>">
							<span class="wpex-overlay"></span>
							<img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php echo esc_attr( $name ); ?>" />
							<div class="wpex-shop-categories-entry-title-wrap wpex-clr">
								<h3 class="wpex-shop-categories-entry-title"><div>
									<span><?php echo wpex_sanitize( $name, 'html' ); ?></span>
								</div></h3>
							</div><!-- .wpex-shop-categories-entry-title-wrap -->
						</a>
					</div><!-- .wpex-shop-categories-entry -->

				<?php endif; ?>

			<?php endforeach; ?>

		</div><!-- .wpex-row -->

	</div><!-- .wpex-shop-categories -->

<?php endif; ?>