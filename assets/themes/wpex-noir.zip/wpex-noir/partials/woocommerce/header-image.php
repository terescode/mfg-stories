<?php
/**
 * Displays the page thumbnail
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Display
if ( ! wpex_has_page_featured_image_overlay_title() ) {
	return;
}

// Get thumbnail
$thumbnail = false;
if ( is_shop() ) {
	$title     = get_the_title( wc_get_page_id( 'shop' ) );
	$title     = $title ? $title : esc_html__( 'Shop', 'noir' );
	$post_id   = wc_get_page_id( 'shop' );
	$thumbnail = get_the_post_thumbnail( $post_id, 'full' );
} elseif ( is_tax() ) {
	$title        = single_term_title( '', false );
	$cat          = get_queried_object();
	$thumbnail_id = get_woocommerce_term_meta( $cat->term_id, 'thumbnail_id', true );
	$thumbnail    = '<img src="'. wp_get_attachment_url( $thumbnail_id ) .'" alt='. $title .' >';
}

// For shop only
if ( $thumbnail && $title ) : ?>

	<div class="wpex-page-thumbnail wpex-clr">
		<?php if ( wpex_has_page_featured_image_overlay_title() ) : ?>
			<div class="wpex-page-thumbnail-title">
				<div class="wpex-page-thumbnail-title-inner">
					<h1><span><?php echo wpex_sanitize( $title, 'html' ); ?></span></h1>
				</div><!-- .wpex-page-thumbnail-title-inner -->
			</div><!-- .wpex-page-thumbnail-title -->
		<?php endif; ?>
		<?php echo wpex_sanitize( $thumbnail, 'img' ); ?>
	</div><!-- .wpex-page-thumbnail -->

<?php endif; ?>