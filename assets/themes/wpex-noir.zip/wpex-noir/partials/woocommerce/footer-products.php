<?php
/**
 * Footer Posts
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Display
$enabled = wpex_get_theme_mod( 'footer_products_enable', true );
$display = false;
if ( $enabled && function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
	$display = true;
}
if ( ! apply_filters( 'wpex_footer_products_display', $display ) ) {
	return;
}

// Get count
$count = get_theme_mod( 'footer_products_count', 4 );
if ( ! $count || 0 == $count ) {
	return;
}

// Prevent stupid shit
if ( $count > 99 ) {
	$count = 10;
}

// Query Args
$args = array(
	'post_type'      => 'product',
	'posts_per_page' => $count,
	'no_found_rows'  => true,
	'order'          => 'DESC',
);

// Order by post views if plugin is active
$query_by = wpex_get_theme_mod( 'footer_products_query', 'featured' );
if ( 'featured' == $query_by ) {
	$args['meta_query'] = array( array(
		'key'   => '_featured',
		'value' => 'yes',
	) );
} elseif ( 'latest' == $query_by ) {
	$args['orderby'] = 'date';
} elseif ( 'category' == $query_by && $category = wpex_get_theme_mod( 'footer_products_query_category' ) ) {
	$args['tax_query'] = array( array(
		'taxonomy' => 'product_cat',
		'field'    => 'ID',
		'terms'    => array( $category ),

	) );
}

// Apply filters to the footer query for child theming
$args = apply_filters( 'wpex_footer_products_args', $args );

// Run Query
$wpex_query = new wp_query( $args );

// Display footer items
if ( $wpex_query->have_posts() ) {

	// Get columns
	$columns = wpex_get_theme_mod( 'footer_products_columns', 4 ); ?>

	<section class="wpex-footer-products-wrap wpex-clr">

		<div class="wpex-container wpex-clr">

			<?php
			// Heading
			$heading = wpex_get_theme_mod( 'footer_products_heading', esc_html__( 'Featured Products', 'noir' ) );
			if ( $heading ) { ?>
				<h6 class="wpex-footer-posts-heading"><?php echo wpex_sanitize( $heading, 'html' ); ?></h6>
			<?php } ?>

			<div class="wpex-footer-products wpex-row wpex-clr">
				<?php
				// Loop through footer products
				$count = 0;
				foreach( $wpex_query->posts as $post ) : setup_postdata( $post );
					$product = new WC_Product( get_the_ID() );
					$count ++; ?>

					<div class="wpex-footer-product wpex-clr wpex-col wpex-col-<?php echo absint( $columns ); ?> wpex-count-<?php echo absint( $count ); ?>">

						<?php if ( has_post_thumbnail() ) : ?>

							<div class="wpex-footer-product-thumbnail wpex-clr">
								<a href="<?php the_permalink(); ?>" title="<?php wpex_esc_title(); ?>"><?php the_post_thumbnail( 'shop_catalog' ); ?></a>
								<?php
								// On sale tag
								woocommerce_show_product_loop_sale_flash(); ?>
							</div><!-- .footer-wpex-post-thumbnail -->

						<?php endif; ?>

						<div class="wpex-footer-product-content wpex-clr">
							<h3 class="wpex-footer-product-title">
								<a href="<?php the_permalink(); ?>" title="<?php wpex_esc_title(); ?>">
									<?php
									// Show title
									the_title(); ?>
								</a>
							</h3>
							<div class="wpex-footer-product-meta">
								<?php echo wpex_sanitize( $product->get_price_html(), 'html' ); ?>
							</div><!-- wpex-footer-product-meta -->
						</div><!-- .footer-post-content -->
					</div><!-- .footer-post -->

					<?php if ( $count == $columns ) $count = 0; ?>

				<?php endforeach; ?>

				</div><!-- .wpex-footer-products -->

		</div><!-- .wpex-container -->

	</section><!-- .wpex-footer-products -->

<?php } // End footer items

// Reset post data
wp_reset_postdata();