<?php
/**
 * The post rating
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Display rating
if ( $rating = get_post_meta( get_the_ID(), 'wpex_post_rating', true ) ) : ?>

	<div class="wpex-post-rating wpex-clr">
		<span itemscope itemtype="http://schema.org/Review">
			<span itemprop="author" itemscope itemtype="http://schema.org/Person" style="display:none;"><span itemprop="name"><?php echo get_the_author(); ?></span></span>
			<span itemprop="itemReviewed" style="display:none;"><?php the_title(); ?></span>
			<span itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">
				<span class="wpex-post-rating-txt wpex-heading-font-family"><?php esc_html_e( 'My rating', 'noir' ); ?>:</span>
				<?php echo wpex_star_rating( $rating ); ?>
				<span class="wpex-post-rating-value"><span itemprop="ratingValue"><?php echo floatval( $rating ); ?></span> <?php esc_html_e( 'out of', 'noir' ); ?> <span itemprop="bestRating">5</span></span> 
			</span>
		</span>
	</div><!-- .wpex-loop-entry-rating -->

<?php endif; ?>