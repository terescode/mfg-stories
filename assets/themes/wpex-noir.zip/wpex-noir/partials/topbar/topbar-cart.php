<?php
/**
 * Topbar Cart
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( WPEX_WOOCOMMERCE_ACTIVE && wpex_get_theme_mod( 'topbar_cart_enable', true ) ) : ?>

	<div class="wpex-topbar-cart wpex-clr">
		<?php echo wpex_woocommerce_cart_count_link(); ?>
	</div><!-- .wpex-topbar-cart -->

<?php endif; ?>