<?php
/**
 * Topbar OffCanvas Menu Toggle
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Display menu if defined
if ( has_nav_menu( 'off_canvas' ) ) : ?>

	<div class="wpex-topbar-ofcanvas-toggle">
		<a href="#" title="<?php esc_html_e( 'Toggle Sidebar', 'noir' ); ?>"><span class="fa fa-bars"></span></a>
	</div><!-- .wpex-topbar-ofcanvas-toggle -->

<?php endif; ?>