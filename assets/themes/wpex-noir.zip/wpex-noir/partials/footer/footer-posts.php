<?php
/**
 * Footer Posts
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Display
$display = wpex_get_theme_mod( 'footer_posts_enable', true );
if ( is_page() || wpex_is_woocommerce() ) {
	$display = false;
}
$display = apply_filters( 'wpex_footer_posts_display', $display );
if ( ! $display ) return;

// Get count
$count = get_theme_mod( 'footer_posts_count' );
$count = $count ? $count : 3;
if ( ! $count || 0 == $count ) {
	return;
}

// Prevent stupid shit
if ( $count > 99 ) {
	$count = 10;
}

// Query Args
$args = array(
	'post_type'           => 'post',
	'posts_per_page'      => $count,
	'no_found_rows'       => true,
	'ignore_sticky_posts' => true,
);

// Query option
$query_by = wpex_get_theme_mod( 'footer_posts_query', 'popular' );

// Order by post views if plugin is active
if ( 'popular' == $query_by ) {
	if ( class_exists( 'Post_Views_Counter' ) ) {
		$args['orderby'] = 'post_views';
	} else {
		$args['orderby'] = 'comment_count';
	}
	$args['order'] = 'DESC';
} elseif ( 'latest' == $query_by ) {
	$args['orderby'] = 'date';
} elseif ( 'category' == $query_by && $category = wpex_get_theme_mod( 'footer_posts_query_category' ) ) {
	$category = wpex_parse_obj_id( $category, 'category' );
	$args['tax_query'] = array( array(
		'taxonomy' => 'category',
		'field'    => 'ID',
		'terms'    => array( $category ),

	) );
}

// Apply filters to the footer query for child theming
$args = apply_filters( 'wpex_footer_posts_args', $args );

// Run Query
$wpex_query = new wp_query( $args );

// Display footer items
if ( $wpex_query->have_posts() ) {

	// Get columns
	$columns = wpex_get_theme_mod( 'footer_posts_columns', 3 ); ?>

	<section class="wpex-footer-posts-wrap wpex-clr">

		<div class="wpex-container wpex-clr">

			<?php
			// Heading
			$heading = wpex_get_theme_mod( 'footer_posts_heading', esc_html__( 'Trending Articles', 'noir' ) );
			if ( $heading ) { ?>
				<h6 class="wpex-footer-posts-heading"><?php echo wpex_sanitize( $heading, 'html' ); ?></h6>
			<?php } ?>

			<div class="wpex-footer-posts wpex-row wpex-clr">
				<?php
				// Loop through footer posts
				$count = 0;
				foreach( $wpex_query->posts as $post ) : setup_postdata( $post );
					$count ++; ?>

					<div class="wpex-footer-post wpex-clr wpex-col wpex-col-<?php echo absint( $columns ); ?> wpex-count-<?php echo absint( $count ); ?>">

						<?php if ( has_post_thumbnail() ) : ?>

							<div class="wpex-footer-post-thumbnail wpex-clr">
								<a href="<?php the_permalink(); ?>" title="<?php wpex_esc_title(); ?>"><?php the_post_thumbnail( 'wpex_footer_posts_entry' ); ?></a>
								<?php
								// Show category tag
								if ( wpex_get_theme_mod( 'entry_category', true )
									&& 'category' != $query_by
									&& $category = wpex_get_post_terms( 'category', true, 'wpex-accent-bg' )
								) : ?>
									<div class="wpex-entry-cat wpex-clr wpex-button-typo">
										<?php echo wpex_sanitize( $category, 'html' ); ?>
									</div><!-- .wpex-entry-cat -->
								<?php endif; ?>
							</div><!-- .footer-wpex-post-thumbnail -->

						<?php endif; ?>

						<div class="wpex-footer-post-content wpex-clr">
							<h3 class="wpex-footer-post-title">
								<a href="<?php the_permalink(); ?>" title="<?php wpex_esc_title(); ?>">
									<?php
									// Show play icon
									if ( wpex_has_post_video() ) {
										echo '<span class="fa fa-play-circle wpex-video-icon"></span>';
									}
									// Show music icon
									if ( wpex_has_post_audio() ) {
										echo '<span class="fa fa-music wpex-music-icon"></span>';
									}
									// Show title
									the_title(); ?>
								</a>
							</h3>
							<div class="wpex-footer-post-meta"><?php esc_html_e( 'Published on', 'noir' ); ?> <?php echo get_the_date(); ?></div>
							</div><!-- .footer-post-content -->
					</div><!-- .footer-post -->

					<?php if ( $count == $columns ) $count = 0; ?>

				<?php endforeach; ?>

				</div><!-- .wpex-footer-posts -->

		</div><!-- .wpex-container -->

	</section><!-- .wpex-footer-posts -->

<?php } // End footer items

// Reset post data
wp_reset_postdata();