<?php
/**
 * Archives top advertisement region
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get ad
if ( is_home() || is_front_page() ) {
	$ad = get_theme_mod(
		'ad_homepage_top',
		'<img src="'. get_template_directory_uri() .'/images/medium-banner.jpg" alt="'. esc_html__( 'Banner', 'noir' ) .'" />'
	);
} else {
	$ad = get_theme_mod(
		'ad_archives_top',
		'<img src="'. get_template_directory_uri() .'/images/medium-banner.jpg" alt="'. esc_html__( 'Banner', 'noir' ) .'" />'
	);
}

// Display
if ( $ad ) : ?>

	<div class="wpex-ad-region wpex-archives-top wpex-clr">
		<?php echo do_shortcode( wpex_sanitize( $ad, 'advertisement' ) ); ?>
	</div><!-- .wpex-ad-region -->

<?php endif; ?>