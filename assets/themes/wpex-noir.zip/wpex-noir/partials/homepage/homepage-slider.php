<?php
/**
 * The main header layout
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_front_page() ) {
	return;
}

$slider = wpex_get_theme_mod( 'homepage_slider', null );

if ( ! $slider ) {
	return;
} ?>

<div class="wpex-homepage-slider wpex-clr"><?php echo do_shortcode( wp_kses_post( $slider ) ); ?></div>