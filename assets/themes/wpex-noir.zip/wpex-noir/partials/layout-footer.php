<?php
/**
 * Footer Layout
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 * @version   1.2.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<?php get_template_part( 'partials/footer/footer-instagram' ); ?>

<?php get_template_part( 'partials/footer/footer-posts' ); ?>

<?php get_template_part( 'partials/woocommerce/footer-products' ); ?>

<footer class="wpex-site-footer">

	<?php if ( wpex_has_footer_widgets() ) : ?>

		<?php get_template_part( 'partials/footer/widgets' ); ?>

	<?php endif; ?>

	<?php if ( get_theme_mod( 'footer_copyright', true  ) ) : ?>
		
		<div class="wpex-footer-bottom">

			<div class="wpex-container wpex-clr">

					<?php get_template_part( 'partials/footer/copyright' ); ?>
			</div><!-- .wpex-container -->

		</div><!-- .wpex-footer-bottom -->

	<?php endif; ?>

</footer><!-- .wpex-site-footer -->