<?php
/**
 * The post entry rating
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Display Rating
if ( $rating = get_post_meta( get_the_ID(), 'wpex_post_rating', true ) ) : ?>

	<div class="wpex-loop-entry-rating wpex-clr">
		<div class="wpex-rating"><?php echo wpex_star_rating( $rating ); ?> <span class="wpex-rating-number"><?php echo floatval( $rating ); ?></span></div>
	</div><!-- .wpex-loop-entry-rating -->

<?php endif; ?>