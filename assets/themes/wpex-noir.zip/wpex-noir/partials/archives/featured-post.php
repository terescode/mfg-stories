<?php
/**
 * Featured Post
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $wp_query;
$featured_post = wpex_get_first_post_with_thumb( $wp_query );

if ( $featured_post ) : ?>

	<?php
	// Get first post data
	$post = get_post( $featured_post );

	// Display featured post
	if ( ! empty( $post ) ) :

		// Get author data
		$author = $post->post_author;
		$author = get_user_by( 'id', $author ); ?>

		<div class="wpex-featured-entry wpex-clr<?php if ( ! has_post_thumbnail() ) echo ' wpex-featured-entry-no-thumb'; ?>">

			<?php
			// Display category tab
			if ( wpex_get_theme_mod( 'entry_category', true ) ) : ?>
			
				<?php get_template_part( 'partials/entry/category' ); ?>

			<?php endif; ?>

			<a href="<?php the_permalink(); ?>" title="<?php wpex_esc_title(); ?>" class="wpex-featured-entry-link wpex-clr">

				<?php the_post_thumbnail( 'wpex_entry_featured' ); ?>

				<header class="wpex-featured-entry-header wpex-clr">
					<h2 class="wpex-featured-entry-title">
						<?php
						// Show play icon
						if ( ! wpex_get_theme_mod( 'entry_embeds', false ) && wpex_has_post_video() ) {
							echo '<span class="fa fa-play-circle wpex-video-icon"></span>';
						} ?>
						<?php the_title(); ?>
					</h2>
					<div class="wpex-featured-entry-meta">
						<span><?php echo wpex_sanitize( $author->display_name, 'html' ); ?></span>
						<span class="wpex-spacer">&middot;</span>
						<span><?php echo wpex_time_ago( $post ); ?></span>
						<?php
						// Display comments
						if ( comments_open() && wpex_has_comments() ) : ?>
						<span class="wpex-spacer">&middot;</span>
						<span><?php comments_number( esc_html__( '0 Comments', 'noir' ), esc_html__( '1 Comment',  'noir' ), esc_html__( '% Comments', 'noir' ) ); ?></span>
						<?php endif; ?>
						<?php
						// Rating
						if ( $rating = get_post_meta( get_the_ID(), 'wpex_post_rating', true ) ) : ?>
							<span class="wpex-spacer">&middot;</span>
							<span><?php echo wpex_star_rating( $rating ); ?></span>
						<?php endif; ?>
					</div>
				</header>

			</a>

		</div><!-- .wpex-featured-entry -->

	<?php endif; ?>

<?php endif; ?>