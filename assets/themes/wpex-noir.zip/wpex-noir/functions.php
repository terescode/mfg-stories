<?php
/**
 * Theme functions and definitions.
 *
 * Sets up the theme and provides some helper functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 *
 * For more information on hooks, actions, and filters,
 * see http://codex.wordpress.org/Plugin_API
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 * @version   1.2.0
 */

class WPEX_Noir_Theme_Setup {

	/**
	 * Start things up
	 *
     * @since  1.0.0
     * @access public
	 */
	public function __construct() {

		// Paths
		$this->template_dir     = get_template_directory();
		$this->template_dir_uri = get_template_directory_uri();

		// Add Filters
		add_filter( 'wpex_gallery_metabox_post_types', array( $this, 'gallery_metabox_post_types' ) );
		add_filter( 'excerpt_more', array( $this, 'excerpt_more' ) );
		add_filter( 'embed_oembed_html', array( $this, 'embed_oembed_html' ), 99, 4 );
		add_filter( 'pre_get_posts', array( $this, 'pre_get_posts' ) );
		add_filter( 'manage_post_posts_columns', array( $this, 'posts_columns' ), 10 );
		add_filter( 'manage_page_posts_columns', array( $this, 'posts_columns' ), 10 );
		add_filter( 'mce_buttons_2', array( $this, 'mce_font_size_select' ) );
		add_filter( 'tiny_mce_before_init', array( $this, 'fontsize_formats' ) );
		add_filter( 'mce_buttons', array( $this, 'formats_button' ) );
		add_filter( 'tiny_mce_before_init', array( $this, 'formats' ) );
		add_filter( 'use_default_gallery_style', array( $this, 'remove_gallery_styles' ) );
		add_filter( 'user_contactmethods', array( $this, 'user_fields' ) );
		add_filter( 'previous_post_link', array( $this, 'previous_post_link' ) );
		add_filter( 'next_post_link', array( $this, 'next_post_link' ) );
		add_filter( 'body_class', array( $this, 'body_classes' ) );
		add_action( 'wp_head', array( $this, 'theme_meta_generator' ), 9999 );
		add_filter( 'wp_nav_menu_items', array( $this, 'menu_add_items' ), 11, 2 );
		add_filter( 'comment_form_fields', array( $this, 'move_comment_form_fields' ) );

		// Actions
		add_action( 'after_setup_theme', array( $this, 'constants' ), 1 );
		add_action( 'after_setup_theme', array( $this, 'load_files' ), 2 );
		add_action( 'after_setup_theme', array( $this, 'setup' ), 3 );
		add_action( 'init', array( $this, 'remove_locale_stylesheet' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'theme_css' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'rtl_css' ), 50 );
		add_action( 'wp_enqueue_scripts', array( $this, 'responsive_css' ), 999 );
		add_action( 'wp_enqueue_scripts', array( $this, 'theme_js' ) );
		add_action( 'widgets_init', array( $this, 'register_sidebars' ) );
		add_action( 'manage_posts_custom_column', array( $this, 'posts_custom_columns' ), 10, 2 );
		add_action( 'manage_pages_custom_column', array( $this, 'posts_custom_columns' ), 10, 2 );
		add_action( 'wp_head', array( $this, 'retina_logo' ) );
		add_action( 'wp_head', array( $this, 'customizer_css' ) );
		add_action( 'wp_footer', array( $this, 'mobile_alternative' ) );
		add_action( 'wp_footer', array( $this, 'off_canvas_menu' ) );

		// Custom Widgets
		$this->load_custom_widgets();

		// Sticky menu
		add_action( 'wp_footer', array( $this, 'sticky_menu' ) );

	}

	/**
	 * Define constants
	 *
     * @since  1.0.0
     * @access public
	 */
	public function constants() {
		define( 'WPEX_WOOCOMMERCE_ACTIVE', class_exists( 'WooCommerce' ) );
	}

	/**
	 * Include functions and classes
	 *
     * @since  1.0.0
     * @access public
	 */
	public function load_files() {

		// WooCommerce tweaks - load first so we can use theme filters and hooks
		if ( WPEX_WOOCOMMERCE_ACTIVE ) {
			require_once ( $this->template_dir .'/inc/woocommerce-config.php' );
		}

		// Include Theme Functions
		require_once( $this->template_dir .'/inc/core-functions.php' );
		require_once( $this->template_dir .'/inc/conditionals.php' );
		require_once( $this->template_dir .'/inc/customizer-config.php' );
		require_once ( $this->template_dir .'/inc/accent-config.php' );
		require_once( $this->template_dir .'/inc/meta-pages.php' );
		require_once( $this->template_dir .'/inc/meta-posts.php' );

		// Include Classes
		require_once ( $this->template_dir .'/inc/classes/accent.php' );
		require_once ( $this->template_dir .'/inc/classes/custom-css/custom-css.php' );
		require_once ( $this->template_dir .'/inc/classes/customizer/customizer.php' );
		require_once ( $this->template_dir .'/inc/classes/gallery-metabox/gallery-metabox.php' );

		// WPML/Polilang config
		require_once ( $this->template_dir .'/inc/translators-config.php' );

	}

	/**
	 * Include custom widgets
	 *
     * @since  1.0.0
     * @access public
	 */
	public function load_custom_widgets() {


		// Apply filters so you can remove custom widgets via a child theme or plugin
		$widgets = apply_filters( 'wpex_theme_widgets', array(
			'social',
			'facebook-page',
			'recent-posts-thumbnails',
			'mailchimp',
			'about',
			'contact-info',
			'instagram-grid',
			'comments-avatar',
			'video',
			'google-map',
			'popular-posts',
		) );

		// Loop through and load widget files
		foreach ( $widgets as $widget ) {
			$widget_file = $this->template_dir .'/inc/classes/widgets/'. $widget .'.php';
			if ( file_exists( $widget_file ) ) {
				require_once( $widget_file );
		   }
		}

	}

	/**
	 * Remove locale_stylesheet so we can load it prior to responsive.css
	 *
     * @since  1.0.0
     * @access public
	 */
	public function remove_locale_stylesheet() {
		remove_action( 'wp_head', 'locale_stylesheet' );
	}

	/**
	 * Functions called during each page load, after the theme is initialized
	 * Perform basic setup, registration, and init actions for the theme
	 *
     * @since  1.0.0
     * @access public
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Action_Reference/after_setup_theme
	 */
	public function setup() {

		// Define content_width variable
		if ( ! isset( $content_width ) ) {
			$content_width = 745;
		}

		// Register navigation menus
		register_nav_menus ( array(
			'main'       => esc_html__( 'Main', 'noir' ),
			'mobile'     => esc_html__( 'Mobile Alternative', 'noir' ),
			'off_canvas' => esc_html__( 'Off Canvas', 'noir' ),
		) );

		// Add editor styles
		add_editor_style( 'css/editor-style.css' );
		
		// Localization support
		load_theme_textdomain( 'noir', get_template_directory() .'/languages' );
			
		// Add theme support
		add_theme_support( 'title-tag' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'custom-background' );
		add_theme_support( 'post-thumbnails' );
		//add_theme_support( 'custom-header' );

		// Add image sizes
		add_image_size(
			'wpex_entry',
			get_theme_mod( 'entry_thumbnail_width', 700 ),
			get_theme_mod( 'entry_thumbnail_height', 350 ),
			wpex_parse_image_crop( get_theme_mod( 'entry_thumbnail_crop' ) )
		);
		add_image_size(
			'wpex_entry_left_right',
			get_theme_mod( 'entry_left_right_thumbnail_width', 500 ),
			get_theme_mod( 'entry_left_right_thumbnail_height', 600 ),
			wpex_parse_image_crop( get_theme_mod( 'entry_left_right_thumbnail_crop' ) ) 
		);
		add_image_size(
			'wpex_entry_grid',
			get_theme_mod( 'entry_grid_thumbnail_width', 700 ),
			get_theme_mod( 'entry_grid_thumbnail_height', 350 ),
			wpex_parse_image_crop( get_theme_mod( 'entry_grid_thumbnail_crop' ) )
		);
		add_image_size(
			'wpex_entry_featured',
			get_theme_mod( 'entry_featured_thumbnail_width', 1050 ),
			get_theme_mod( 'entry_featured_thumbnail_height', 540 ),
			wpex_parse_image_crop( get_theme_mod( 'entry_featured_thumbnail_crop' ) )
		);
		add_image_size(
			'wpex_post',
			get_theme_mod( 'post_thumbnail_width', 1050 ),
			get_theme_mod( 'post_thumbnail_height', 540 ),
			wpex_parse_image_crop( get_theme_mod( 'post_thumbnail_crop' ) )
		);
		add_image_size(
			'wpex_related_entry',
			get_theme_mod( 'post_related_thumbnail_width', 700 ),
			get_theme_mod( 'post_related_thumbnail_height', 350 ),
			wpex_parse_image_crop( get_theme_mod( 'post_related_thumbnail_crop' ) )
		);
		add_image_size(
			'wpex_footer_posts_entry',
			get_theme_mod( 'footer_loop_thumbnail_width', 700 ),
			get_theme_mod( 'footer_loop_thumbnail_height', 350 ),
			wpex_parse_image_crop( get_theme_mod( 'footer_loop_thumbnail_crop' ) )
		);

		// Add support for page excerpts
		add_post_type_support( 'page', 'excerpt' );

	}

	/**
	 * Define post types for the gallery metabox
	 *
     * @since  1.0.0
     * @access public
	 */
	public function gallery_metabox_post_types( $post_types ) {
		return array( 'post' );
	}

	/**
	 * Load custom CSS scripts in the front end
	 *
     * @since  1.0.0
     * @access public
     *
     * @link   https://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 */
	public function theme_css() {

		// Define css directory
		$css_dir_uri = $this->template_dir_uri .'/css/';

		// Font Awesome
		wp_enqueue_style( 'font-awesome', $css_dir_uri .'font-awesome.min.css' );

		// Slider
		wp_enqueue_style( 'lightslider', $css_dir_uri .'lightslider.css' );

		// Popups
		wp_enqueue_style( 'magnific-popup', $css_dir_uri .'magnific-popup.css' );

		// Main CSS
		wp_enqueue_style( 'style', get_stylesheet_uri() );

		// Remove Contact Form 7 Styles
		if ( function_exists( 'wpcf7_enqueue_styles') ) {
			wp_dequeue_style( 'contact-form-7' );
		}

	}

	/**
	 * Load RTL CSS
	 *
     * @since  1.0.0
     * @access public
     *
     * @link   https://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 */
	public function rtl_css() {
		if ( is_RTL() || ! empty( $_GET['rtl'] ) ) {
			wp_enqueue_style( 'wpex-rtl', $this->template_dir_uri .'/css/rtl.css' );
		}
	}

	/**
	 * Load responsive css
	 *
     * @since  1.0.0
     * @access public
     *
     * @link   https://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 */
	public function responsive_css() {
		if ( wpex_is_responsive() ) {
			wp_enqueue_style( 'wpex-responsive', $this->template_dir_uri .'/css/responsive.css' );
		} else {
			wp_deregister_style( 'woocommerce-smallscreen' );
			wp_dequeue_style( 'woocommerce-smallscreen' );
		}
	}

	/**
	 * Load custom JS scripts in the front end
	 *
     * @since  1.0.0
     * @access public
     *
	 * @link   https://codex.wordpress.org/Function_Reference/wp_enqueue_script
	 */
	public function theme_js() {

		// Define js directory
		$js_dir_uri = $this->template_dir_uri .'/js/';

		// Comment reply
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		// Check if js should be minified
		$minify_js = wpex_has_minified_scripts();
		$minify_js = false;

		// Localize scripts
		$localize  = apply_filters( 'wpex_localize', array(
			'isRTL'             => is_rtl(),
			'wpGalleryLightbox' => true,
			'mobileMenuOpen'    => get_theme_mod( 'mobile_menu_open_text', esc_html__( 'Click here to navigate', 'noir' ) ),
			'mobileMenuClose'   => get_theme_mod( 'mobile_menu_close_text', esc_html__( 'Close navigation', 'noir' ) ),
		) );

		// Output minified js
		if ( $minify_js ) {

			wp_enqueue_script( 'wpex-theme-min', $js_dir_uri .'theme-min.js', array( 'jquery' ), false, true );
			wp_localize_script( 'wpex-theme-min', 'wpexLocalize', $localize );

		}

		// Non-minified js
		else {

			wp_enqueue_script( 'fitvids', $js_dir_uri .'plugins/jquery.fitvids.js', array( 'jquery' ), '1.1', true );

			wp_enqueue_script( 'imagesloaded', $js_dir_uri .'plugins/imagesloaded.pkgd.min.js', array( 'jquery' ), '3.1.8', true );

			wp_enqueue_script( 'magnific-popup', $js_dir_uri .'plugins/jquery.magnific-popup.js', array( 'jquery' ), '1.0.0', true );

			wp_enqueue_script( 'lightslider', $js_dir_uri .'plugins/lightslider.js', array( 'jquery' ), false, true );

			wp_enqueue_script( 'wpex-equal-heights', $js_dir_uri .'plugins/equal-heights.js', array( 'jquery' ), '1.0', true );

			// Theme functions
			wp_enqueue_script( 'wpex-functions', $js_dir_uri .'functions.js', array( 'jquery' ), false, true );
			wp_localize_script( 'wpex-functions', 'wpexLocalize', $localize );

		}

		// Sticky header always non-min
		if ( get_theme_mod( 'sticky_menu' ) ) {
			wp_enqueue_script( 'sticky-js', $js_dir_uri .'sticky.js', array( 'jquery' ), '1.1', true );
		}

	}

	/**
	 * Registers the theme sidebars
	 *
     * @since  1.0.0
     * @access public
	 *
	 * @link   http://codex.wordpress.org/Function_Reference/register_sidebar
	 */
	function register_sidebars() {

		// Sidebar
		register_sidebar( array(
			'name'          => esc_html__( 'Sidebar - Main', 'noir' ),
			'id'            => 'sidebar',
			'before_widget' => '<div class="wpex-sidebar-widget %2$s wpex-clr">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		) );

		// Sidebar
		register_sidebar( array(
			'name'          => esc_html__( 'Sidebar - Pages', 'noir' ),
			'id'            => 'sidebar_pages',
			'before_widget' => '<div class="wpex-sidebar-widget %2$s wpex-clr">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		) );

		// WooCommerce Sidebar
		if ( WPEX_WOOCOMMERCE_ACTIVE ) {

			register_sidebar( array(
				'name'          => esc_html__( 'WooCommerce - Sidebar', 'noir' ),
				'id'            => 'sidebar_woocommerce',
				'before_widget' => '<div class="wpex-sidebar-widget %2$s wpex-clr">',
				'after_widget'  => '</div>',
				'before_title'  => '<h4 class="widget-title">',
				'after_title'   => '</h4>',
			) );

		}

		// Instagram footer
		register_sidebar( array(
			'name'          => esc_html__( 'Instagram Footer', 'noir' ),
			'id'            => 'instagram_footer',
			'before_widget' => '<div class="instagram-footer-widget %2$s wpex-clr">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
			'description'   => esc_html__( 'Drag the Instagram widget into this area for a full-width instagram grid before your site footer.', 'noir' ),
		) );

		// Get footer columns
		$cols = get_theme_mod( 'footer_columns', '4' );

		// Footer 1
		if ( $cols >= 1 ) {

			register_sidebar( array(
				'name'          => esc_html__( 'Footer 1', 'noir' ),
				'id'            => 'footer-one',
				'before_widget' => '<div class="footer-widget %2$s wpex-clr">',
				'after_widget'  => '</div>',
				'before_title'  => '<h6 class="widget-title">',
				'after_title'   => '</h6>',
			) );

		}

		// Footer 2
		if ( $cols > 1 ) {

			register_sidebar( array(
				'name'          => esc_html__( 'Footer 2', 'noir' ),
				'id'            => 'footer-two',
				'before_widget' => '<div class="footer-widget %2$s wpex-clr">',
				'after_widget'  => '</div>',
				'before_title'  => '<h6 class="widget-title">',
				'after_title'   => '</h6>',
			) );

		}

		// Footer 3
		if ( $cols > 2 ) {

			register_sidebar( array(
				'name'          => esc_html__( 'Footer 3', 'noir' ),
				'id'            => 'footer-three',
				'before_widget' => '<div class="footer-widget %2$s wpex-clr">',
				'after_widget'  => '</div>',
				'before_title'  => '<h6 class="widget-title">',
				'after_title'   => '</h6>',
			) );

		}

		// Footer 4
		if ( $cols > 3 ) {

			register_sidebar( array(
				'name'          => esc_html__( 'Footer 4', 'noir' ),
				'id'            => 'footer-four',
				'before_widget' => '<div class="footer-widget %2$s wpex-clr">',
				'after_widget'  => '</div>',
				'before_title'  => '<h6 class="widget-title">',
				'after_title'   => '</h6>',
			) );

		}

	}
	
	/**
	 * Adds classes to the body_class function
	 *
     * @since  1.0.0
     * @access public
	 *
	 * @link   http://codex.wordpress.org/Function_Reference/body_class
	 */
	public function body_classes( $classes ) {

		// Add post layout
		$classes[] = wpex_get_post_layout();

		// Offcanvas sidebar
		if ( has_nav_menu( 'off_canvas' ) ) {
			$classes[] = 'wpex-has-offcanvas-menu';
			if ( ! get_theme_mod( 'sticky_menu', false ) ) {
				$classes[] = 'wpex-has-offcanvas-menu-translate';
			}
		}

		// Topbar
		if ( wpex_get_theme_mod( 'topbar_social_enable', true ) ) {
			$classes[] = 'wpex-has-topbar-social';
		}

		// Entry style
		if ( $entry_style = wpex_get_blog_entry_style() ) {
			$classes[] = 'wpex-entry-style-'. $entry_style;
		}
		
		// Return classes
		return $classes;

	}

	/**
	 * Return custom excerpt more string
	 *
     * @since  1.0.0
     * @access public
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Filter_Reference/excerpt_more
	 */
	public function excerpt_more( $more ) {
		return $more;
	}

	/**
	 * Alters the default oembed output
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   https://developer.wordpress.org/reference/hooks/embed_oembed_html/
	 */
	function embed_oembed_html( $html, $url, $attr, $post_id ) {
		return '<div class="wpex-responsive-embed">' . $html . '</div>';
	}

	/**
	 * Alter the main query
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Action_Reference/pre_get_posts
	 */
	public function pre_get_posts( $query ) {

		// Do nothing in admin
		if ( is_admin() ) {
			return;
		}

		// Alter search results
		if ( get_theme_mod( 'search_posts_only', true )
			&& $query->is_main_query()
			&& is_search()
		) {
			$post_type_query_var = false;
			if ( ! empty( $_GET[ 'post_type' ] ) ) {
				$post_type_query_var = true;
			}
			if ( ! $post_type_query_var ) {
				$query->set( 'post_type', array( 'post' ) );
			}
		}

		// Exclude posts on the homepage
		if ( $query->is_home() && $query->is_main_query() && function_exists( 'wpex_exclude_home_ids' ) ) {
			$ids = wpex_exclude_home_ids();
			if ( is_array( $ids ) && ! empty( $ids ) ) {
				$query->set( 'post__not_in', $ids );
			}
		}

		// Alter posts per page
		if ( $query->is_main_query() && ! empty( $_GET['posts_per_page'] ) ) {
			return $query->set( 'posts_per_page', $_GET['posts_per_page'] );
		}

	}

	/**
	 * Adds new "Featured Image" column to the WP dashboard
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Filter_Reference/manage_posts_columns
	 */
	public function posts_columns( $defaults ) {
		$defaults['wpex_post_thumbs'] = esc_html__( 'Featured Image', 'noir' );
		return $defaults;
	}

	/**
	 * Display post thumbnails in WP admin
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Filter_Reference/manage_posts_columns
	 */
	public function posts_custom_columns( $column_name, $id ) {
		$id = get_the_ID();
		if ( $column_name != 'wpex_post_thumbs' ) {
			return;
		}
		if ( has_post_thumbnail( $id ) ) {
			$img_src = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), 'thumbnail', false );
			if( ! empty( $img_src[0] ) ) { ?>
					<img src="<?php echo esc_url( $img_src[0] ); ?>" alt="<?php echo esc_attr( the_title_attribute( 'echo=0' ) ); ?>" style="max-width:100%;max-height:90px;" />
				<?php
			}
		} else {
			echo '&mdash;';
		}
	}

	/**
	 * Adds js for the retina logo
	 *
	 * @since 1.0.0
	 */
	function retina_logo() {
		$logo_url    = esc_url( get_theme_mod( 'logo_retina' ) );
		$logo_height = intval( get_theme_mod( 'logo_retina_height' ) );
		if ( $logo_url && $logo_height ) {
			echo '<!-- Retina Logo --><script type="text/javascript">jQuery(function($){if (window.devicePixelRatio >= 2) {$("#wpex-site-logo img").attr("src", "'. esc_url( $logo_url ) .'");$("#wpex-site-logo img").css("height", "'. intval( $logo_height ) .'");}});</script>';
		}
	}

	/**
	 * Add Font size select to tinymce
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Filter_Reference/mce_buttons,_mce_buttons_2,_mce_buttons_3,_mce_buttons_4
	 */
	public function mce_font_size_select( $buttons ) {
		array_unshift( $buttons, 'fontsizeselect' );
		return $buttons;
	}
	
	/**
	 * Customize default font size selections for the tinymce
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Filter_Reference/mce_buttons,_mce_buttons_2,_mce_buttons_3,_mce_buttons_4
	 */
	public function fontsize_formats( $initArray ) {
		$initArray['fontsize_formats'] = "9px 10px 12px 13px 14px 16px 18px 21px 24px 28px 32px 36px";
		return $initArray;
	}

	/**
	 * Add Formats Button
	 *
	 * @since  1.0.0
	 * @access public 
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Filter_Reference/mce_buttons,_mce_buttons_2,_mce_buttons_3,_mce_buttons_4
	 */
	function formats_button( $buttons ) {
		array_push( $buttons, 'styleselect' );
		return $buttons;
	}

	/**
	 * Add new formats
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   http://codex.wordpress.org/TinyMCE_Custom_Styles
	 */
	public function formats( $settings ) {
		$new_formats = array(
			array(
				'title'     => esc_html__( 'Highlight', 'noir' ),
				'inline'    => 'span',
				'classes'   => 'wpex-text-highlight'
			),
			array(
				'title' => esc_html__( 'Buttons', 'noir' ),
				'items' => array(
					array(
						'title'     => esc_html__( 'Default', 'noir' ),
						'selector'  => 'a',
						'classes'   => 'wpex-theme-button'
					),
					array(
						'title'     => esc_html__( 'Red', 'noir' ),
						'selector'  => 'a',
						'classes'   => 'wpex-theme-button red'
					),
					array(
						'title'     => esc_html__( 'Green', 'noir' ),
						'selector'  => 'a',
						'classes'   => 'wpex-theme-button green'
					),
					array(
						'title'     => esc_html__( 'Blue', 'noir' ),
						'selector'  => 'a',
						'classes'   => 'wpex-theme-button blue'
					),
					array(
						'title'     => esc_html__( 'Orange', 'noir' ),
						'selector'  => 'a',
						'classes'   => 'wpex-theme-button orange'
					),
					array(
						'title'     => esc_html__( 'Black', 'noir' ),
						'selector'  => 'a',
						'classes'   => 'wpex-theme-button black'
					),
					array(
						'title'     => esc_html__( 'White', 'noir' ),
						'selector'  => 'a',
						'classes'   => 'wpex-theme-button white'
					),
					array(
						'title'     => esc_html__( 'Clean', 'noir' ),
						'selector'  => 'a',
						'classes'   => 'wpex-theme-button clean'
					),
				),
			),
			array(
				'title' => esc_html__( 'Notices', 'noir' ),
				'items' => array(
					array(
						'title'     => esc_html__( 'Default', 'noir' ),
						'block'     => 'div',
						'classes'   => 'wpex-notice'
					),
					array(
						'title'     => esc_html__( 'Info', 'noir' ),
						'block'     => 'div',
						'classes'   => 'wpex-notice wpex-info'
					),
					array(
						'title'     => esc_html__( 'Warning', 'noir' ),
						'block'     => 'div',
						'classes'   => 'wpex-notice wpex-warning'
					),
					array(
						'title'     => esc_html__( 'Success', 'noir' ),
						'block'     => 'div',
						'classes'   => 'wpex-notice wpex-success'
					),
				),
			),
		);
		$settings['style_formats'] = json_encode( $new_formats );
		return $settings;
	}

	/**
	 * Remove gallery styles
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   https://developer.wordpress.org/reference/hooks/use_default_gallery_style/
	 */
	public function remove_gallery_styles() {
		return false;
	}

	/**
	 * Add new user fields
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   http://codex.wordpress.org/Plugin_API/Filter_Reference/user_contactmethods
	 */
	public function user_fields( $contactmethods ) {

		// Add Twitter
		if ( ! isset( $contactmethods['wpex_twitter'] ) ) {
			$contactmethods['wpex_twitter'] = 'Noir - Twitter';
		}

		// Add Facebook
		if ( ! isset( $contactmethods['wpex_facebook'] ) ) {
			$contactmethods['wpex_facebook'] = 'Noir - Facebook';
		}

		// Add GoglePlus
		if ( ! isset( $contactmethods['wpex_googleplus'] ) ) {
			$contactmethods['wpex_googleplus'] = 'Noir - Google+';
		}

		// Add LinkedIn
		if ( ! isset( $contactmethods['wpex_linkedin'] ) ) {
			$contactmethods['wpex_linkedin'] = 'Noir - LinkedIn';
		}

		// Add Pinterest
		if ( ! isset( $contactmethods['wpex_pinterest'] ) ) {
			$contactmethods['wpex_pinterest'] = 'Noir - Pinterest';
		}

		// Add Pinterest
		if ( ! isset( $contactmethods['wpex_instagram'] ) ) {
			$contactmethods['wpex_instagram'] = 'Noir - Instagram';
		}

		// Return contactmethods
		return $contactmethods;

	}

	/**
	 * Filters the previous post link HTML if empty to display simple text
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   https://developer.wordpress.org/reference/functions/get_adjacent_post_link/
	 */
	public function previous_post_link( $output ) {

		if ( ! $output ) {
			$text = get_theme_mod( 'post_next_text' );
			$text = $text ? $text : esc_html__( 'Next Article', 'noir' );
			$output = '<div class="nav-previous wpex-disabled"><span class="wpex-previous-post-disabled">'. esc_html( $text ) .'<i class="fa fa-chevron-right"></i></span></div>';
		}

		return $output;

	}

	/**
	 * Filters the next post link HTML if empty to display simple text
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   https://developer.wordpress.org/reference/functions/get_adjacent_post_link/
	 */
	public function next_post_link( $output ) {
		if ( ! $output ) {
			$text = get_theme_mod( 'post_prev_text' );
			$text = $text ? $text : esc_html__( 'Previous Article', 'noir' );
			$output = '<div class="nav-next wpex-disabled"><span class="wpex-next-post-disabled"><span class="fa fa-chevron-left"></span>'. esc_html( $text ) .'</span></div>';
		}

		return $output;

	}


	/**
	 * Adds extra CSS to the head based on customizer settings
	 *
	 * @since  1.0.0
	 * @access public
	 */
	public function customizer_css() {

		// Add css
		$css = '';

		// Container width
		$width = get_theme_mod( 'layout_container_width' );
		if ( $width && strpos( $width, '%' ) == false ) {
			$width = intval( $width );
			$width = $width ? $width .'px' : null;
		}
		if ( $width ) {
			$css .= '.wpex-container { width: '. $width .'; }';
		}

		// Content width
		$width = $this->px_pct( get_theme_mod( 'layout_content_width' ) );
		if ( $width ) {
			$css .= '.wpex-content-area { width: '. $width .'; max-width: none; }';
		}

		// Sidebar width
		$width = $this->px_pct( get_theme_mod( 'layout_sidebar_width' ) );
		if ( $width ) {
			$css .= '.wpex-sidebar { width: '. $width .'; max-width: none; }';
		}

		// Container Max Width
		if ( wpex_is_responsive() ) {

			$width = intval( get_theme_mod( 'layout_container_max_width' ) );

			if ( $width && '85' !== $width ) {
				$css .= '.wpex-container { max-width: '. $width .'%; }';
			}

		}

		// Sidebar heading tag
		$mod = get_theme_mod( 'sidebar_heading_bg' );
		if ( $mod ) {
			$css .= '.wpex-sidebar-widget .widget-title:after { border-top-color: '. $mod .'; }';
		}

		// Minitfy CSS
		$css = wpex_minify_css( $css );

		// Return css
		if ( $css ) {
			echo '<!-- Theme Inline CSS --><style type="text/css">'. $css .'</style>';
		}

	}

	/**
     * Returns a Pixel or Percent
     *
     * @access private
     * @since  1.0.0
     */
    private function px_pct( $data ) {

        if ( 'none' == $data || '0px' == $data ) {
            return '0';
        } elseif ( strpos( $data, '%' ) ) {
            return $data;
        } elseif ( strpos( $data , '&#37;' ) ) {
        	return $data;
        } elseif ( $data = floatval( $data ) ) {
            return $data .'px';
        }

    }

	/**
	 * Adds meta generator for 
	 *
	 * @since 3.1.0
	 */
	public function theme_meta_generator() {
		$theme = wp_get_theme();
		echo '<meta name="generator" content="Built With The Noir WordPress Theme '. $theme->get( 'Version' ) .'" />';
		echo "\r\n";
	}

	/**
	 * Adds alternative mobile menu
	 *
	 * @since 3.1.0
	 */
	public function mobile_alternative() {
		if ( has_nav_menu( 'mobile' ) ) {
			echo wp_nav_menu( array(
				'theme_location'  => 'mobile',
				'fallback_cb'     => false,
				'container_class' => 'wpex-mobile-menu-alt',
				'menu_class'      => 'wpex-dropdown-menu',
				'walker'          => new WPEX_Dropdown_Walker_Nav_Menu,
			) );
		}
	}

	/**
	 * Off-Canvas menu
	 *
	 * @since 3.1.0
	 */
	public function off_canvas_menu() {
		if ( has_nav_menu( 'off_canvas' ) ) {
			echo '<div class="wpex-off-canvas-menu .wpex-clr">';
				echo '<div class="wpex-off-canvas-menu-close"><a href="#">x</a></div>';
				wp_nav_menu( array(
					'theme_location' => 'off_canvas',
					'fallback_cb'    => false,
				) );
			echo '</div>';
		}
	}

	/**
	 * Adds extra items to the end of the main menu
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @link   http://codex.wordpress.org/Function_Reference/wp_get_nav_menu_items
	 */
	public function menu_add_items( $items, $args ) {
		return $items;
	}

	/**
	 * Adds js to wp_footer for sticky menu
	 *
	 * @since  1.1.0
	 * @access public
	 */
	public function sticky_menu() {

		// Return if disabled
		if ( ! get_theme_mod( 'sticky_menu', false ) ) {
			return;
		}

		// Mobile menu breakpoint
		$breakpoint = apply_filters( 'sticky_menu_mobile_breakpoint', 959 );
		$breakpoint = intval( $breakpoint ) ? intval( $breakpoint ) : '959'; ?>

		<script>
			( function( $ ) {
				'use strict';
				$( document ).ready(function() {
					if ( $( window ).width() > <?php echo $breakpoint; ?> ) {
						$( '.wpex-site-nav' ).sticky( {
							topSpacing      : 0,
							responsiveWidth : true,
							className       : 'wpex-sticky-nav'
						} );
					}
				} );
			} ) ( jQuery );
		</script>

	<?php }

	/**
	 * Move Comment form field back to bottom which was altered in WP 4.4
	 *
	 * @since 1.2.5
	 */
	public static function move_comment_form_fields( $fields ) {
		$comment_field = $fields['comment'];
		unset( $fields['comment'] );
		$fields['comment'] = $comment_field;
		return $fields;
	}

}
$wpex_noir_theme_setup = new WPEX_Noir_Theme_Setup;