<?php
/**
 * Creates the admin panel for the customizer
 *
 * @package		Noir
 * @subpackage	Customizer
 * @author		Alexander Clarke
 * @copyright	Copyright (c) 2015, WPExplorer.com
 * @link		http://www.wpexplorer.com
 * @since		1.0.0
 */

// Only Needed in the admin
if ( ! is_admin() ) {
	return;
}

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add sub menu page to the Appearance menu.
 *
 * @link http://codex.wordpress.org/Function_Reference/add_theme_page
 */
if ( ! function_exists( 'wpex_customizer_admin' ) ) {
	function wpex_customizer_admin() {
		add_submenu_page(
			'themes.php',
			esc_html__( 'Customizer Manager', 'noir' ), 
			esc_html__( 'Customizer Manager', 'noir' ),
			'manage_options',
			'wpex-customizer-manager',
			'wpex_customizer_options_page'
		);
	}
}
add_action( 'admin_menu', 'wpex_customizer_admin' );

/**
 * Register a setting and its sanitization callback.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_setting
 */
if ( ! function_exists( 'wpex_customizer_register_settings' ) ) {
	function wpex_customizer_register_settings() {
		register_setting( 'wpex_customizer_options', 'wpex_customizer_options', 'wpex_customizer_options_sanitize' );
	}
}
add_action( 'admin_init', 'wpex_customizer_register_settings' );

/**
 * Displays all messages registered to 'wpex-customizer-notices'
 *
 * @link http://codex.wordpress.org/Function_Reference/settings_errors
 */
if ( ! function_exists( 'wpex_customizer_admin_notices_action' ) ) {
	function wpex_customizer_admin_notices_action() {
		settings_errors( 'wpex-customizer-notices' );
	}
}
add_action( 'admin_notices', 'wpex_customizer_admin_notices_action' );

/**
 * Sanitization callback
 */
if ( ! function_exists( 'wpex_customizer_options_sanitize' ) ) {
	function wpex_customizer_options_sanitize( $options ) {
		// Import the imported options
		if ( $options ) {
			// Delete options if import set to -1
			if ( '-1' == $options['reset'] ) {
				// Get menu locations
				$locations = get_theme_mod( 'nav_menu_locations' );
				$save_menus = array();
				foreach( $locations as $key => $val ) {
					$save_menus[$key] = $val;
				}
				// Remove all mods
				remove_theme_mods();
				// Re-add the menus
				set_theme_mod( 'nav_menu_locations', array_map( 'absint', $save_menus ) );
				// Error messages
				$error_msg = esc_html__( 'All theme customizer settings have been reset.', 'noir' );
				$error_type = 'updated';
			}
			// Set theme mods based on json data
			elseif( ! empty( $options['import'] ) ) {
				// Decode input data
				$theme_mods = json_decode( $options['import'], true );
				// Validate json file then set new theme options
				if ( '0' == json_last_error() ) {
					foreach ( $theme_mods as $theme_mod => $value ) {
						set_theme_mod( $theme_mod, $value );
					}
					$error_msg  = esc_html__( 'Theme customizer settings imported successfully.', 'noir' );
					$error_type = 'updated';
				}
				// Display invalid json data error
				else {
					$error_msg  = esc_html__( 'Invalid Import Data.', 'noir' );
					$error_type = 'error';
				}
			}
			// No json data entered
			else {
				$error_msg = esc_html__( 'No import data found.', 'noir' );
				$error_type = 'error';
			}
			// Make sure the settings data is reset! 
			$options = array(
				'import'	=> '',
				'reset'		=> '',
			);
		}
		// Display message
		add_settings_error(
			'wpex-customizer-notices',
			esc_attr( 'settings_updated' ),
			$error_msg,
			$error_type
		);

		// Return options
		return $options;
	}
}

/**
 * Settings page output
 */
if ( ! function_exists( 'wpex_customizer_options_page' ) ) {
	function wpex_customizer_options_page() { ?>
		<div class="wrap">
		<h2><?php esc_html_e( 'Import, Export or Reset Customizer Settings', 'noir' ); ?></h2>
		<?php
		// Default options
		$options = array(
				'import'	=> '',
				'reset'		=> '',
		); ?>
		<form method="post" action="options.php">
			<?php
			/**
			 * Output nonce, action, and option_page fields for a settings page
			 *
			 * @link http://codex.wordpress.org/Function_Reference/settings_fields
			 */
			$options = get_option( 'wpex_customizer_options', $options );
			settings_fields( 'wpex_customizer_options' ); ?>
			<table class="form-table">
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Export Customizer Options', 'noir' ); ?></th>
					<td>
						<?php
						// Get an array of all the theme mods
						if ( $theme_mods = get_theme_mods() ) {
							$mods = array();
							foreach ( $theme_mods as $theme_mod => $value ) {
								$mods[$theme_mod] = maybe_unserialize( $value );
							}
							$json = json_encode( $mods );
							$disabled = '';
						} else {
							$json = esc_html__( 'No Options Found', 'noir' );
							$disabled = 'disabled';
						}
						echo '<textarea rows="10" cols="50" readonly id="wpex-customizer-export" style="width:100%;">' . $json . '</textarea>'; ?>
						<p class="submit">
							<a href="#" class="button-primary wpex-highlight-options <?php echo esc_attr( $disabled ); ?>"><?php esc_html_e( 'Highlight Options', 'noir' ); ?></a>
						</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><?php esc_html_e( 'Import Customizer Options', 'noir' ); ?></th>
					<td>
						<?php
						// Get import data
						$import = isset( $options['import'] ) ? $options['import'] : ''; ?>
						<textarea name="wpex_customizer_options[import]" rows="10" cols="50" style="width:100%;"><?php echo stripslashes( $import ); ?></textarea>
						<input id="wpex-reset-hidden" name="wpex_customizer_options[reset]" type="hidden" value=""></input>
						<p class="submit">
							<input type="submit" class="button-primary wpex-submit-form" value="<?php esc_html_e( 'Import Options', 'noir' ) ?>" />
							<a href="#" class="button-secondary wpex-delete-options"><?php esc_html_e( 'Reset Options', 'noir' ); ?></a>
							<a href="#" class="button-secondary wpex-cancel-delete-options" style="display:none;"><?php esc_html_e( 'Cancel Reset', 'noir' ); ?></a>
						</p>
						<div class="wpex-delete-options-warning error inline" style="display:none;">
							<p style="margin:.5em 0;"><?php esc_html_e( 'This will reset ALL your theme Customizer modifications (theme_mods) except your menu locations. Always make sure you have a backup of your settings before resetting, just incase!', 'noir' ); ?></p>
						</div>
					</td>
				</tr>
			</table>
		</form>
		<script>
			(function($) {
				"use strict";
					$( '.wpex-highlight-options' ).click( function() {
						$( '#wpex-customizer-export' ).focus().select();
						return false;
					});
					$( '.wpex-delete-options' ).click( function() {
						$(this).hide();
						$( '.wpex-delete-options-warning, .wpex-cancel-delete-options' ).show();
						$( '.wpex-submit-form' ).val( "<?php esc_html_e( 'Confirm Reset', 'noir' ); ?>" );
						$( '#wpex-reset-hidden' ).val( '-1' );
						return false;
					});
					$( '.wpex-cancel-delete-options' ).click( function() {
						$(this).hide();
						$( '.wpex-delete-options-warning' ).hide();
						$( '.wpex-delete-options' ).show();
						$( '.wpex-submit-form' ).val( "<?php esc_html_e( 'Import Options', 'noir' ); ?>" );
						$( '#wpex-reset-hidden' ).val( '' );
						return false;
					});
			})(jQuery);
		</script>
		</div>
	<?php }
}