<?php
/**
 * Tweaks for WooCommerce
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

global $wpex_woocommerce_setup;

/**
 * Configures WooCommerce for this theme
 *
 * @since 1.0.0
 */
if ( ! class_exists( 'WPEX_WooCommerce_Setup' ) ) {

	class WPEX_WooCommerce_Setup {

		/**
		 * Start things up
		 *
		 * @since 1.0.0
		 */
		public function __construct() {

			// Add support
			add_theme_support( 'woocommerce' );
			add_theme_support( 'wc-product-gallery-zoom' );
			add_theme_support( 'wc-product-gallery-lightbox' );
			add_theme_support( 'wc-product-gallery-slider' );

			// Filters
			add_filter( 'wpex_post_layout', array( $this, 'post_layouts' ), 20 );
			add_filter( 'loop_shop_per_page', array( $this, 'loop_shop_per_page' ), 20 );
			add_filter( 'woocommerce_pagination_args', array( $this, 'pagination_args' ) );
			add_filter( 'loop_shop_columns', array( $this, 'loop_shop_columns' ), 1, 10 );
			add_filter( 'woocommerce_cross_sells_columns', array( $this, 'loop_shop_columns' ) );
			add_filter( 'woocommerce_output_related_products_args', array( $this, 'related_products_args' ) );
			add_filter( 'woocommerce_show_page_title', array( $this, 'woocommerce_show_page_title' ) );
			add_filter( 'woocommerce_sale_flash', array( $this, 'custom_sale_flash' ), 10, 3 );
			add_filter( 'woocommerce_product_thumbnails_columns', array( $this, 'product_thumbnails_columns' ) );
			add_filter( 'post_class', array( $this, 'add_product_entry_classes' ), 40, 3 );
			add_filter( 'wpex_localize', array( $this, 'wpex_localize' ) );
			add_filter( 'add_to_cart_fragments', array( $this, 'cart_count' ) );
			add_filter( 'wpex_accent_backgrounds', array( $this, 'accent_backgrounds' ) );

			// Remove actions
			remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
			remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
			remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
			remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );

			// Add actions
			add_action( 'wp_enqueue_scripts', array( $this, 'add_scripts' ) );
			add_action( 'woocommerce_enqueue_styles', array( $this, 'remove_styles' ) );
			add_action( 'woocommerce_before_single_product_summary', array( $this, 'single_product_boxed_container_open' ), 5 );
			add_action( 'woocommerce_after_single_product_summary', array( $this, 'single_product_boxed_container_close' ), 11 );
			add_action( 'wpex_page_after_boxed_container', array( $this, 'cross_sell_display' ) );
			add_action( 'woocommerce_after_single_product_summary', array( $this, 'product_social_share' ), 11 );
			add_action( 'woocommerce_after_single_product_summary', array( $this, 'upsell_display' ), 15 );

		}

		/**
		 * Adds scripts
		 *
		 * @since 1.0.0
		 */
		public function add_scripts() {

			// Define css dir
			$css_dir_uri = get_template_directory_uri() .'/css/';

			// Main CSS
			wp_enqueue_style( 'wpex-woocommerce', $css_dir_uri .'wpex-woocommerce.css' );

			// Responsive CSS
			if ( wpex_is_responsive() ) {
				wp_enqueue_style( 'wpex-woocommerce-responsive', $css_dir_uri .'wpex-woocommerce-responsive.css' );
			}

			// Match Height JS
			if ( is_shop() || is_product() || is_cart() ) {
				wp_enqueue_script( 'match-height' );
			}

		}

		/**
		 * Remove WooCommerce styles not needed for this theme.
		 *
		 * @since 1.2.5
		 * @link  http://docs.woothemes.com/document/disable-the-default-stylesheet/
		 */
		public static function remove_styles( $enqueue_styles ) {
			if ( ! is_account_page() && is_array( $enqueue_styles ) ) {
				unset( $enqueue_styles['woocommerce-smallscreen'] );
				unset( $enqueue_styles['woocommerce_prettyPhoto_css'] );
			}
			return $enqueue_styles;
		}

		/**
		 * Alters woo layouts
		 *
		 * @since 1.0.0
		 */
		public function post_layouts( $layout ) {

			// Left sidebar for shop
			if ( is_shop() ) {
				$layout = get_theme_mod( 'woo_shop_layout' );
				$layout = $layout ? $layout : 'right-sidebar';
			}

			// Product
			elseif ( is_singular( 'product') ) {
				$layout = get_theme_mod( 'woo_product_layout' );
				$layout = $layout ? $layout : 'right-sidebar';
			}

			// Full-width for WooCommerce cart
			elseif ( is_cart() ) {
				$layout = 'full-width';
			}

			// Full-width for WooCommerce checkout
			elseif ( is_checkout() ) {
				$layout = 'full-width';
			}

			// Account
			elseif( is_account_page() ) {
				$layout = 'full-width';
			}

			// Return layout
			return $layout;
		}

		/**
		 * Alters the number of products per page for the shop
		 *
		 * @since 1.0.0
		 */
		public function loop_shop_per_page() {
			$count = get_theme_mod( 'woo_shop_count' );
			$count = $count ? $count : 12;
			return $count;
		}

		/**
		 * Alters the columns for the shop page
		 *
		 * @since 1.0.0
		 */
		public function loop_shop_columns() {
			global $wpex_shop_cols;
			if ( ! empty( $_GET['shop_columns'] ) ) {
				return $_GET['shop_columns'];
			} elseif ( $wpex_shop_cols ) {
				return $wpex_shop_cols;
			} elseif ( is_cart() || is_checkout() ) {
				$cols = get_theme_mod( 'woo_cart_checkout_upsells_coluns' );
				$cols = $cols ? $cols : '4';
			} else {
				$cols = get_theme_mod( 'woo_shop_columns' );
				$cols = $cols ? $cols : '3';
			}
			$cols = $cols ? $cols : '3'; // Fallback
			$cols = apply_filters( 'wpex_woocommerce_product_columns', $cols );
			return $cols;
		}

		/**
		 * Alters the related items count and columns
		 *
		 * @since 1.0.0
		 */
		public function related_products_args( $args ) {
			$args['posts_per_page'] = wpex_get_theme_mod( 'woo_related_count', 3 );
			$args['columns'] = wpex_get_theme_mod( 'woo_related_columns', 3 );
			return $args;
		}

		/**
		 * Remove the shop page title
		 *
		 * @since 1.0.0
		 */
		public function woocommerce_show_page_title() {
			return get_theme_mod( 'woo_shop_title', false );
		}

		/**
		 * Change sale text
		 *
		 * @since 1.0.0
		 */
		public function custom_sale_flash( $text, $post, $_product ) {
		  return '<span class="onsale"> '. get_theme_mod( 'woo_sale_text', esc_html__( 'Sale', 'noir' ) ) .' </span>';  
		}

		/**
		 * Change number of thumbnails columns on product page
		 *
		 * @since 1.0.0
		 */
		public function product_thumbnails_columns( $number ){
			return 4;
		}

		/**
		 * Open Div before product summary
		 *
		 * @since 1.0.0
		 */
		public function single_product_boxed_container_open(){
			echo '<div class="product-wrapper wpex-clr">';
		}

		/**
		 * Close div after product summary
		 *
		 * @since 1.0.0
		 */
		public function single_product_boxed_container_close(){
			echo '</div>';
		}

		/**
		 * Add classes to WooCommerce product entries.
		 *
		 * @since  1.0.0
		 * @access public
		 *
		 * @link   http://codex.wordpress.org/Function_Reference/post_class
		 */
		public function add_product_entry_classes( $classes ) {
			global $product, $woocommerce_loop;
			if ( in_array( 'wpex-woo-entry', $classes ) && $woocommerce_loop && ! empty( $woocommerce_loop['columns'] ) ) {
				$classes[] = 'wpex-col';
				$classes[] = 'wpex-col-'. $woocommerce_loop['columns'];
			}
			return $classes;
		}

		/**
		 * Tweaks pagination arguments
		 *
		 * @since  1.0.0
		 * @access public
		 */
		public function pagination_args( $args ) {
			$args['prev_text'] = '<i class="fa fa-angle-left"></i>';
			$args['next_text'] = '<i class="fa fa-angle-right"></i>';
			return $args;
		}

		/**
		 * Change products per row for upsells.
		 *
		 * @since  1.0.0
		 * @access public
		 */
		public function upsell_display() {
			woocommerce_upsell_display(
				wpex_get_theme_mod( 'woo_upsells_count', 3 ),
				wpex_get_theme_mod( 'woo_upsells_columns', 3 )
			);
		}

		/**
		 * Displays cross-sells in the correct location
		 *
		 * @since  1.0.0
		 * @access public
		 */
		public function cross_sell_display() {
			if ( function_exists( 'is_cart' ) && is_cart() ) { ?>
				<div class="woocommerce wpex-clr">
					<?php woocommerce_cross_sell_display(
						wpex_get_theme_mod( 'woo_cross_sells_count', 4 ),
						wpex_get_theme_mod( 'woo_cross_sells_columns', 4 )
					); ?>
				</div>
			<?php }
		}

		/**
		 * Add to wpex_localize
		 *
		 * @since  1.0.0
		 * @access public
		 */
		public function wpex_localize( $array ) {
			$array['productReviewsTitle'] = esc_html__( 'Product Reviews', 'noir' );
			return $array;
		}

		/**
		 * Add menu cart item to the Woo fragments so it updates with AJAX
		 *
		 * @since 1.0.0
		 */
		public static function cart_count( $fragments ) {
			$fragments['.wpex-woo-cart-fragment'] = wpex_woocommerce_cart_count_link();
			return $fragments;
		}

		/**
		 * Adds accent elements
		 *
		 * @since  1.0.0
		 * @access public
		 */
		public function accent_backgrounds( $array ) {
			return array_merge( $array, array(

				// Woo Buttons
				'.woocommerce nav.woocommerce-pagination .page-numbers a:hover',
				'.woocommerce nav.woocommerce-pagination .page-numbers span.current',
				'.woocommerce div.product form.cart .button',
				'.wpex-sidebar .widget_product_categories a:hover',
				'.woocommerce #content input.button, .woocommerce #respond input#submit',
				'.woocommerce a.button, .woocommerce button.button',
				'.woocommerce input.button, .woocommerce-page #content input.button',
				'.woocommerce-page #respond input#submit, .woocommerce-page a.button',
				'.woocommerce-page button.button, .woocommerce-page input.button',
				'.woocommerce #respond input#submit.alt',
				'.woocommerce a.button.alt',
				'.woocommerce button.button.alt',
				'.woocommerce input.button.alt',
				'.woocommerce #content input.button:hover',
				'.woocommerce #respond input#submit:hover',
				'.woocommerce a.button:hover',
				'.woocommerce button.button:hover',
				'.woocommerce input.button:hover',
				'.woocommerce-page #content input.button:hover',
				'.woocommerce-page #respond input#submit:hover',
				'.woocommerce-page a.button:hover',
				'.woocommerce-page button.button:hover',
				'.woocommerce-page input.button:hover',
				'.woocommerce #respond input#submit.alt:hover',
				'.woocommerce a.button.alt:hover',
				'.woocommerce button.button.alt:hover',
				'.woocommerce input.button.alt:hover',
				'.woocommerce .products a.button.added',
				'body .widget_shopping_cart .buttons .button:hover',

				// Woo Tabs
				'.woocommerce #content div.product .woocommerce-tabs ul.tabs li.active a',
				'.woocommerce div.product .woocommerce-tabs ul.tabs li.active a',
				'.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active a',
				'.woocommerce-page div.product .woocommerce-tabs ul.tabs li.active a',

			) );
		}

		/**
		 * Display social share on products
		 *
		 * @since 1.0.2
		 */
		public static function product_social_share() {
			if ( wpex_get_theme_mod( 'woo_product_social_share', false ) ) {
				get_template_part( 'partials/woocommerce/share' );
			}
		}

	}
}
$wpex_woocommerce_setup = new WPEX_WooCommerce_Setup;