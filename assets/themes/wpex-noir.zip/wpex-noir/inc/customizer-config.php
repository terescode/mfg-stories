<?php
/**
 * Defines all settings for the customizer class
 *
 * @package Noir WordPress Theme
 * @author Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link http://www.wpexplorer.com
 * @since 1.0.0
 */

if ( ! function_exists( 'wpex_customizer_config' ) ) {

	function wpex_customizer_config( $panels ) {

		/*-----------------------------------------------------------------------------------*/
		/* - Useful vars
		/*-----------------------------------------------------------------------------------*/

		// Columns
		$columns = array(
			'' => esc_html__( 'Default', 'noir' ),
			1 => 1,
			2 => 2,
			3 => 3,
			4 => 4,
		);

		// Accents
		$accents = array(
			'' => esc_html__( 'Default', 'noir' ),
			'#27ae60' => esc_html__( 'Green', 'noir' ),
			'#e67e22' => esc_html__( 'Orange', 'noir' ),
			'#2980b9' => esc_html__( 'Blue', 'noir' ),
			'#2c3e50' => esc_html__( 'Navy', 'noir' ),
			'#c0392b' => esc_html__( 'Red', 'noir' ),
			'#8e44ad' => esc_html__( 'Purple', 'noir' ),
			'#16a085' => esc_html__( 'Teal', 'noir' ),
			'#1abc9c' => esc_html__( 'Turquoise', 'noir' ),
			'#7f8c8d' => esc_html__( 'Gray', 'noir' ),
		);

		// Layouts
		$layouts = array(
			'' => esc_html__( 'Default', 'noir' ),
			'right-sidebar' => esc_html__( 'Right Sidebar', 'noir' ),
			'left-sidebar' => esc_html__( 'Left Sidebar', 'noir' ),
			'full-width' => esc_html__( 'No Sidebar', 'noir' ),
		);
		
		// Font Weights
		$font_weights = array(
			'' => esc_html__( 'Default', 'noir' ),
			'100' => '100',
			'200' => '200',
			'300' => '300',
			'400' => '400',
			'500' => '500',
			'600' => '600',
			'700' => '700',
			'800' => '800',
			'900' => '900',
		);

		// Font Styles
		$font_styles = array(
			'' => esc_html__( 'Default', 'noir' ),
			'normal' => esc_html__( 'Normal', 'noir' ),
			'italic' => esc_html__( 'Italic', 'noir' ),
			'oblique' => esc_html__( 'Oblique', 'noir' ),
		);

		// Categories
		$categories;
		$get_categories = get_categories( array(
			'orderby' => 'name'
		) );
		if ( ! empty( $get_categories ) ) {
			foreach ( $get_categories as $cat ) {
				$categories[$cat->term_id] = $cat->name;
			}
		}

		/*-----------------------------------------------------------------------------------*/
		/* - General Panel
		/*-----------------------------------------------------------------------------------*/
		$panels['general'] = array(
			'title' => esc_html__( 'General Theme Settings', 'noir' ),
			'sections' => array()
		);

		// Site Widths
		$panels['general']['sections']['site-widths'] = array(
			'id' => 'wpex_site_widths',
			'title' => esc_html__( 'Site Widths', 'noir' ),
			'settings' => array(
				array(
					'id' => 'layout_container_width',
					'control' => array(
						'label' => esc_html__( 'Container Width', 'noir' ),
						'type' => 'text',
						'desc' => esc_html__( 'Default:', 'noir' ) .' 1050px',
					),
				),
				array(
					'id' => 'layout_container_max_width',
					'control' => array(
						'label' => esc_html__( 'Container Max Width Percent', 'noir' ),
						'type' => 'text',
						'active_callback' => 'wpex_is_responsive',
						'desc' => esc_html__( 'Default:', 'noir' ) .' 85%',
					),
				),
				array(
					'id' => 'layout_content_width',
					'control' => array(
						'label' => esc_html__( 'Content Area Width', 'noir' ),
						'type' => 'text',
						'desc' => esc_html__( 'Default:', 'noir' ) .' 67%',
					),
				),
				array(
					'id' => 'layout_sidebar_width',
					'control' => array(
						'label' => esc_html__( 'Sidebar Width', 'noir' ),
						'type' => 'text',
						'desc' => esc_html__( 'Default:', 'noir' ) .' 29%',
					),
				),
			),
		);

		// Layouts
		$panels['general']['sections']['layouts'] = array(
			'id' => 'wpex_layouts',
			'title' => esc_html__( 'Layouts', 'noir' ),
			'settings' => array(
				array(
					'id' => 'home_layout',
					'control' => array(
						'label' => esc_html__( 'Homepage Layout', 'noir' ),
						'type' => 'select',
						'choices' => $layouts,
					),
				),
				array(
					'id' => 'archives_layout',
					'control' => array(
						'label' => esc_html__( 'Archives Layout', 'noir' ),
						'type' => 'select',
						'choices' => $layouts,
						'desc' => esc_html__( 'Categories, tags, author...etc', 'noir' ),
					),
				),
				array(
					'id' => 'search_layout',
					'control' => array(
						'label' => esc_html__( 'Search Layout', 'noir' ),
						'type' => 'select',
						'choices' => $layouts,
					),
				),
				array(
					'id' => 'post_layout',
					'control' => array(
						'label' => esc_html__( 'Post Layout', 'noir' ),
						'type' => 'select',
						'choices' => $layouts,
					),
				),
				array(
					'id' => 'page_layout',
					'control' => array(
						'label' => esc_html__( 'Page Layout', 'noir' ),
						'type' => 'select',
						'choices' => $layouts,
					),
				),
			),
		);

		// Responsive
		$panels['general']['sections']['responsive'] = array(
			'id' => 'wpex_responsive',
			'title' => esc_html__( 'Responsiveness', 'noir' ),
			'settings' => array(
				array(
					'id' => 'responsive',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Enable', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'mobile_menu_open_text',
					'default' => esc_html__( 'Click here to navigate', 'noir' ),
					'control' => array(
						'label' => esc_html__( 'Toggle Menu Open Text', 'noir' ),
						'type' => 'text',
						'active_callback' => 'wpex_is_responsive',
					),
				),
				array(
					'id' => 'mobile_menu_close_text',
					'default' => esc_html__( 'Close navigation', 'noir' ),
					'control' => array(
						'label' => esc_html__( 'Toggle Menu Close Text', 'noir' ),
						'type' => 'text',
						'active_callback' => 'wpex_is_responsive',
					),
				),
			),
		);

		// Header Section
		$panels['general']['sections']['general'] = array(
			'id' => 'wpex_general',
			'title' => esc_html__( 'Header', 'noir' ),
			'settings' => array(
				array(
					'id' => 'site_description',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Display description?', 'noir' ),
						'type' => 'checkbox'
					),
				),
				array(
					'id' => 'sticky_menu',
					'control' => array(
						'label' => esc_html__( 'Sticky Menu', 'noir' ),
						'type' => 'checkbox',
						'description' => esc_html__( 'For desktops only.', 'noir' ),
					),
				),
				array(
					'id' => 'logo',
					'control' => array(
						'label' => esc_html__( 'Custom Logo', 'noir' ),
						'type' => 'upload',
					),
				),
				array(
					'id' => 'logo_retina',
					'control' => array(
						'label' => esc_html__( 'Custom Retina Logo', 'noir' ),
						'type' => 'upload',
					),
				),
				array(
					'id' => 'logo_retina_height',
					'control' => array(
						'label' => esc_html__( 'Standard Logo Height', 'noir' ),
						'desc' => esc_html__( 'Enter the standard height for your logo. Used to set your retina logo to the correct dimensions', 'noir' ),
					),
				),
			),
		);

		// Topbar Social
		$social_options = wpex_header_social_options_array();
		
		if ( $social_options ) {

			$panels['general']['sections']['topbar'] = array(
				'id' => 'wpex_social_header',
				'title' => esc_html__( 'Topbar', 'noir' ),
				'desc' => esc_html__( 'Enter the full URL to your social media profile.', 'noir' ),
				'settings' => array(
					array(
						'id' => 'topbar_enable',
						'default' => true,
						'control' => array(
						'label' => esc_html__( 'Enable Topbar', 'noir' ),
						'type' => 'checkbox',
						),
					),
				),
			);

			if ( wpex_is_woocommerce_active() ) {
				$panels['general']['sections']['topbar']['settings']['topbar_cart_enable'] = array(
					'id' => 'topbar_cart_enable',
					'default' => true,
					'control' => array(
					'label' => esc_html__( 'Enable Cart Link', 'noir' ),
					'type' => 'checkbox',
					),
				);
			}

			$panels['general']['sections']['topbar']['settings']['topbar_social_enable'] = array(
				'id' => 'topbar_social_enable',
				'default' => true,
				'control' => array(
				'label' => esc_html__( 'Enable Social', 'noir' ),
				'type' => 'checkbox',
				),
			);

			$panels['general']['sections']['topbar']['settings']['topbar_social_target_blank'] = array(
				'id' => 'topbar_social_target_blank',
				'transport' => 'postMessage',
				'control' => array(
					'label' => esc_html__( 'Open Social Links In New Tab?', 'noir' ),
					'type' => 'checkbox',
					'active_callback' => 'wpex_active_callback_topbar_social',
				),
			);

			foreach ( $social_options as $key => $val ) {

				$panels['general']['sections']['topbar']['settings']['topbar_social_'. $key] = array(
					'id' => 'topbar_social_'. $key,
					'control' => array(
						'label' => $val['label'] .' - '. esc_html__( 'URL', 'noir' ),
						'active_callback' => 'wpex_active_callback_topbar_social'
					),
				);


			}

		}

		// Home
		$panels['general']['sections']['home'] = array(
			'id' => 'wpex_site_home',
			'title' => esc_html__( 'Homepage', 'noir' ),
			'settings' => array(
				array(
					'id' => 'homepage_slider',
					'control' => array(
						'label' => esc_html__( 'Homepage Slider', 'noir' ),
						'type' => 'textarea',
						'description' => esc_html__( 'Enter your slider shortcode or custom HTML if you want to display static content such as an image instead.', 'noir' ),
					),
				),
				array(
					'id' => 'home_h1_heading',
					'control' => array(
						'label' => esc_html__( 'Homepage h1 Heading', 'noir' ),
						'type' => 'text',
					),
				),
				array(
					'id' => 'home_entry_style',
					'default' => 'left_right',
					'control' => array(
						'label' => esc_html__( 'Entry Style', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'left_right' => esc_html__( 'Left Thumbnail & Right Content', 'noir' ),
							'full' => esc_html__( 'Full Thumbnail', 'noir' ),
							'grid' => esc_html__( 'Grid', 'noir' ),
						),
					),
				),
				array(
					'id' => 'home_entry_columns',
					'default' => '1',
					'control' => array(
						'label' => esc_html__( 'Grid Columns', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'1' => '1',
							'2' => '2',
							'3' => '3',
							'4' => '4',
						),
						'active_callback' => 'wpex_active_callback_home_has_grid',
					),
				),
				array(
					'id' => 'home_entry_content_display',
					'default' => 'excerpt',
					'control' => array(
						'label' => esc_html__( 'Entry Displays?', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'excerpt' => esc_html__( 'Custom Excerpt', 'noir' ),
							'content' => esc_html__( 'Full Content', 'noir' ),
						),
					),
				),
				array(
					'id' => 'home_entry_excerpt_length',
					'default' => 30,
					'control' => array(
						'label' => esc_html__( 'Entry Excerpt Length', 'noir' ),
						'type' => 'text',
						'desc' => esc_html__( 'How many words to display per excerpt', 'noir' ),
						'active_callback' => 'wpex_has_custom_excerpt'
					),
				),
			)
		);

		// Entries
		$panels['general']['sections']['entries'] = array(
			'id' => 'wpex_entries',
			'title' => esc_html__( 'Entries', 'noir' ),
			'settings' => array(
				array(
					'id' => 'archive_featured_post',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Display First Post Large?', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'pagination_style',
					'default' => 'numbered',
					'control' => array(
						'label' => esc_html__( 'Pagination Style', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'numbered' => esc_html__( 'Numbered', 'noir' ),
							'next_prev' => esc_html__( 'Next/Prev Links', 'noir' ),
						),
					),
				),
				array(
					'id' => 'entry_style',
					'default' => 'left_right',
					'control' => array(
						'label' => esc_html__( 'Entry Style', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'left_right' => esc_html__( 'Left Thumbnail & Right Content', 'noir' ),
							'full' => esc_html__( 'Full Thumbnail', 'noir' ),
							'grid' => esc_html__( 'Grid', 'noir' ),
						),
					),
				),
				array(
					'id' => 'entry_columns',
					'default' => '1',
					'control' => array(
						'label' => esc_html__( 'Grid Columns', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'1' => '1',
							'2' => '2',
							'3' => '3',
							'4' => '4',
						),
						'active_callback' => 'wpex_active_callback_has_grid',
					),
				),
				array(
					'id' => 'entry_content_display',
					'default' => 'excerpt',
					'control' => array(
						'label' => esc_html__( 'Entry Displays?', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'excerpt' => esc_html__( 'Custom Excerpt', 'noir' ),
							'content' => esc_html__( 'Full Content', 'noir' ),
						),
					),
				),
				array(
					'id' => 'entry_excerpt_length',
					'default' => 30,
					'control' => array(
						'label' => esc_html__( 'Entry Excerpt Length', 'noir' ),
						'type' => 'text',
						'desc' => esc_html__( 'How many words to display per excerpt', 'noir' ),
						'active_callback' => 'wpex_has_custom_excerpt'
					),
				),
				array(
					'id' => 'entry_equal_heights',
					'default' => false,
					'control' => array(
						'label' => esc_html__( 'Entry Equal Heights', 'noir' ),
						'type' => 'checkbox',
						'desc' => esc_html__( 'Sets an equal height for the title, meta and excerpt so that the readmore button aligns at the bottom of the entries.', 'noir' ),
					),
				),
				array(
					'id' => 'entry_thumbnail',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Entry Thumbnail', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'entry_embeds',
					'control' => array(
						'label' => esc_html__( 'Entry Embeds', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'entry_category',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Entry Category Tag', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'entry_category_first_only',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Display First Category Only', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'entry_meta',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Entry Meta', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'entry_meta_date',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Entry Meta Date', 'noir' ),
						'type' => 'checkbox',
						'active_callback' => 'wpex_customizer_entry_has_meta'
					),
				),
				array(
					'id' => 'entry_meta_author',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Entry Meta Author', 'noir' ),
						'type' => 'checkbox',
							'active_callback' => 'wpex_customizer_entry_has_meta'
					),
				),
				array(
					'id' => 'entry_meta_comments',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Entry Meta Comments', 'noir' ),
						'type' => 'checkbox',
							'active_callback' => 'wpex_customizer_entry_has_meta'
					),
				),
				array(
					'id' => 'entry_readmore',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Entry Readmore', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'entry_readmore_text',
					'control' => array(
						'label' => esc_html__( 'Entry Readmore Text', 'noir' ),
						'type' => 'text',
					),
				),
				array(
					'id' => 'entry_social_share',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Entry Social Share', 'noir' ),
						'type' => 'checkbox',
					),
				),
			),
		);

		// Posts
		$panels['general']['sections']['posts'] = array(
			'id' => 'wpex_posts',
			'title' => esc_html__( 'Posts', 'noir' ),
			'settings' => array(
				array(
					'id' => 'post_thumbnail',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Thumbnail', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_category',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Category Tag', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_category_first_only',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Display First Category Only', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_meta',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Meta', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_meta_date',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Meta Date', 'noir' ),
						'type' => 'checkbox',
						'active_callback' => 'wpex_customizer_post_has_meta'
					),
				),
				array(
					'id' => 'post_meta_author',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Meta Author', 'noir' ),
						'type' => 'checkbox',
						'active_callback' => 'wpex_customizer_post_has_meta'
					),
				),
				array(
					'id' => 'post_meta_comments',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Meta Comments', 'noir' ),
						'type' => 'checkbox',
							'active_callback' => 'wpex_customizer_entry_has_meta'
					),
				),
				array(
					'id' => 'post_tags',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Tags', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_share',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Social Share', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_author_info',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Author Box', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_related',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Related', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_related_displays',
					'default' => 'related_category',
					'control' => array(
						'label' => esc_html__( 'Post Related: Displays?', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'related_category' => esc_html__( 'Recent From Same Category', 'noir' ),
							'random' => esc_html__( 'Random Posts', 'noir' ),
						),
						'active_callback' => 'wpex_customizer_has_related_posts',
					),
				),
				array(
					'id' => 'post_related_heading',
					'control' => array(
						'label' => esc_html__( 'Post Related: Heading', 'noir' ),
						'type' => 'text',
						'active_callback' => 'wpex_customizer_has_related_posts',
					),
				),
				array(
					'id' => 'post_related_columns',
					'default' => '3',
					'control' => array(
						'label' => esc_html__( 'Post Related: Columns', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'1' => '1',
							'2' => '2',
							'3' => '3',
							'4' => '4',
						),
						'active_callback' => 'wpex_customizer_has_related_posts',
					),
				),
				array(
					'id' => 'post_related_count',
					'default' => '6',
					'control' => array(
						'label' => esc_html__( 'Post Related: Count', 'noir' ),
						'type' => 'number',
						'active_callback' => 'wpex_customizer_has_related_posts',
					),
				),
				array(
					'id' => 'post_next_prev',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Post Next/Previous', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'post_next_prev_in_same_term',
					'default' => false,
					'control' => array(
						'label' => esc_html__( 'Post Next/Previous From Same Category', 'noir' ),
						'type' => 'checkbox',
						'active_callback' => 'wpex_customizer_post_navigation_in_same_term',
					),
				),
				array(
					'id' => 'post_prev_text',
					'control' => array(
						'label' => __( 'Post Previous Text', 'noir' ),
						'type' => 'text',
						'active_callback' => 'wpex_customizer_post_navigation_in_same_term',
					),
				),
				array(
					'id' => 'post_next_text',
					'control' => array(
						'label' => __( 'Post Next Text', 'noir' ),
						'type' => 'text',
						'active_callback' => 'wpex_customizer_post_navigation_in_same_term',
					),
				),
			),
		);

		// Footer Posts
		$panels['general']['sections']['footer_posts'] = array(
			'id' => 'wpex_footer_posts',
			'title' => esc_html__( 'Footer Posts', 'noir' ),
			'settings' => array(
				array(
					'id' => 'footer_posts_enable',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Enable', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'footer_posts_heading',
					'default' => esc_html__( 'Trending Articles', 'noir' ),
					'control' => array(
						'label' => esc_html__( 'Heading', 'noir' ),
						'type' => 'text',
					),
				),
				array(
					'id' => 'footer_posts_query',
					'control' => array(
						'label' => esc_html__( 'Query By', 'noir' ),
						'type' => 'select',
						'description' => esc_html__( 'When ordered by most popular it will first check for the Most Viewed plugin to order by most viewed otherwise it will fallback to most commented.', 'noir' ),
						'choices' => array(
							'popular' => esc_html__( 'Most Popular', 'noir' ),
							'latest' => esc_html__( 'Latest', 'noir' ),
							'category' => esc_html__( 'Custom Category', 'noir' ),
						),
					),
				),
				array(
					'id' => 'footer_posts_query_category',
					'control' => array(
						'label' => esc_html__( 'Category', 'noir' ),
						'type' => 'select',
						'choices' => $categories,
						'active_callback' => 'wpex_active_callback_footer_posts_query_category'
					),
				),
				array(
					'id' => 'footer_posts_count',
					'default' => 3,
					'control' => array(
						'label' => esc_html__( 'Count', 'noir' ),
						'type' => 'number',
					),
				),
				array(
					'id' => 'footer_posts_columns',
					'default' => 3,
					'control' => array(
						'label' => esc_html__( 'Columns', 'noir' ),
						'type' => 'select',
						'choices' => array(
							1 => 1,
							2 => 2,
							3 => 3,
							4 => 4,
						),
					),
				),
			),
		);

		// Footer
		$panels['general']['sections']['footer'] = array(
			'id' => 'wpex_footer',
			'title' => esc_html__( 'Footer', 'noir' ),
			'settings' => array(
				array(
					'id' => 'footer_widget_columns',
					'default' => 4,
					'control' => array(
						'label' => esc_html__( 'Footer Widgets Columns', 'noir' ),
						'type' => 'select',
						'choices' => array(
							'disable' => esc_html__( 'None - Disable', 'noir' ),
							1 => 1,
							2 => 2,
							3 => 3,
							4 => 4,
						)
					),
				),
				array(
					'id' => 'footer_copyright',
					'default' => '<a href="http://www.wordpress.org" title="WordPress" target="_blank">WordPress</a> Theme Designed &amp; Developed by <a href="http://www.wpexplorer.com/" target="_blank" title="WPExplorer">WPExplorer</a>',
					'control' => array(
						'label' => esc_html__( 'Footer Copyright', 'noir' ),
						'type' => 'textarea',
					),
				),
			),
		);

		// Advertisement
		$panels['general']['sections']['ads'] = array(
			'id' => 'wpex_ads',
			'title' => esc_html__( 'Advertisements', 'noir' ),
			'settings' => array(
				array(
					'id' => 'ad_homepage_top',
					'default' => '<img src="'. get_template_directory_uri() .'/images/medium-banner.jpg" alt="'. esc_html__( 'Banner', 'noir' ) .'" />',
					'control' => array(
						'label' => esc_html__( 'Homepage: Top', 'noir' ),
						'type' => 'textarea',
					),
				),
				array(
					'id' => 'ad_homepage_bottom',
					'default' => '<img src="'. get_template_directory_uri() .'/images/medium-banner.jpg" alt="'. esc_html__( 'Banner', 'noir' ) .'" />',
					'control' => array(
						'label' => esc_html__( 'Homepage: Bottom', 'noir' ),
						'type' => 'textarea',
					),
				),
				array(
					'id' => 'ad_archives_top',
					'default' => '<img src="'. get_template_directory_uri() .'/images/medium-banner.jpg" alt="'. esc_html__( 'Banner', 'noir' ) .'" />',
					'control' => array(
						'label' => esc_html__( 'Archives: Top', 'noir' ),
						'type' => 'textarea',
					),
				),
				array(
					'id' => 'ad_archives_bottom',
					'default' => '<img src="'. get_template_directory_uri() .'/images/medium-banner.jpg" alt="'. esc_html__( 'Banner', 'noir' ) .'" />',
					'control' => array(
						'label' => esc_html__( 'Archives: Bottom', 'noir' ),
						'type' => 'textarea',
					),
				),
				array(
					'id' => 'ad_single_top',
					'default' => '<img src="'. get_template_directory_uri() .'/images/medium-banner.jpg" alt="'. esc_html__( 'Banner', 'noir' ) .'" />',
					'control' => array(
						'label' => esc_html__( 'Post: Top', 'noir' ),
						'type' => 'textarea',
					),
				),
				array(
					'id' => 'ad_single_bottom',
					'default' => '<img src="'. get_template_directory_uri() .'/images/medium-banner.jpg" alt="'. esc_html__( 'Banner', 'noir' ) .'" />',
					'control' => array(
						'label' => esc_html__( 'Post: Bottom', 'noir' ),
						'type' => 'textarea',
					),
				),
			),
		);

		// Discussion
		$panels['general']['sections']['discussion'] = array(
			'id' => 'wpex_site_discussion',
			'title' => esc_html__( 'Discussion', 'noir' ),
			'settings' => array(
				array(
					'id' => 'comments_on_pages',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Comments For Pages', 'noir' ),
						'type' => 'checkbox',
					),
				),
				array(
					'id' => 'comments_on_posts',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Comments For Posts', 'noir' ),
						'type' => 'checkbox',
					),
				),
			)
		);

		// Discussion
		$panels['general']['sections']['search'] = array(
			'id' => 'wpex_search',
			'title' => esc_html__( 'Search Results', 'noir' ),
			'settings' => array(
				array(
					'id' => 'search_posts_only',
					'default' => true,
					'control' => array(
						'label' => esc_html__( 'Search posts only.', 'noir' ),
						'type' => 'checkbox',
					),
				),
			)
		);

		/*-----------------------------------------------------------------------------------*/
		/* - WooCommerce
		/*-----------------------------------------------------------------------------------*/

		if ( wpex_is_woocommerce_active() ) {

			// Categories
			$product_categories = '';
			$get_categories = get_terms( 'product_cat', array(
				'orderby' => 'name'
			) );
			if ( ! empty( $get_categories ) ) {
				foreach ( $get_categories as $cat ) {
					$product_categories[$cat->term_id] = $cat->name;
				}
			}

			$panels['woocommerce'] = array(
				'title' => esc_html__( 'WooCommerce', 'noir' ),
				'sections' => array()
			);

			// Shop Section
			$panels['woocommerce']['sections']['shop'] = array(
				'id' => 'wpex_woocommerce_shop',
				'title' => esc_html__( 'Shop', 'noir' ),
				'settings' => array(
					array(
						'id' => 'woo_shop_layout',
						'control' => array(
							'label' => esc_html__( 'Layout', 'noir' ),
							'type' => 'select',
							'choices' => $layouts,
						),
					),
					array(
						'id' => 'woo_shop_categories',
						'default' => true,
						'control' => array(
							'label' => esc_html__( 'Display Categories', 'noir' ),
							'type' => 'checkbox',
						),
					),
					array(
						'id' => 'woo_shop_count',
						'default' => 12,
						'control' => array(
							'label' => esc_html__( 'Shop Count', 'noir' ),
							'type' => 'text',
						),
					),
					array(
						'id' => 'woo_shop_columns',
						'default' => 3,
						'control' => array(
							'label' => esc_html__( 'Shop Columns', 'noir' ),
							'type' => 'select',
							'choices' => array(
								1 => 1,
								2 => 2,
								3 => 3,
								4 => 4,
							),
						),
					),
				),
			);

			// Product Section
			$panels['woocommerce']['sections']['product'] = array(
				'id' => 'wpex_woocommerce_product',
				'title' => esc_html__( 'Product', 'noir' ),
				'settings' => array(
					array(
						'id' => 'woo_product_layout',
						'control' => array(
							'label' => esc_html__( 'Layout', 'noir' ),
							'type' => 'select',
							'choices' => $layouts,
						),
					),
					array(
						'id' => 'woo_product_social_share',
						'default' => false,
						'control' => array(
							'label' => esc_html__( 'Social Share', 'noir' ),
							'type' => 'checkbox',
						),
					),
					array(
						'id' => 'woo_upsells_count',
						'default' => 3,
						'control' => array(
							'label' => esc_html__( 'Up-sells Count', 'noir' ),
							'type' => 'text',
						),
					),
					array(
						'id' => 'woo_upsells_columns',
						'default' => 3,
						'control' => array(
							'label' => esc_html__( 'Up-Sells Columns', 'noir' ),
							'type' => 'select',
							'choices' => array(
								1 => 1,
								2 => 2,
								3 => 3,
								4 => 4,
							),
						),
					),
					array(
						'id' => 'woo_related_count',
						'default' => 3,
						'control' => array(
							'label' => esc_html__( 'Related Count', 'noir' ),
							'type' => 'text',
						),
					),
					array(
						'id' => 'woo_related_columns',
						'default' => 3,
						'control' => array(
							'label' => esc_html__( 'Related Columns', 'noir' ),
							'type' => 'select',
							'choices' => array(
								1 => 1,
								2 => 2,
								3 => 3,
								4 => 4,
							),
						),
					),
				),
			);

			// Footer Posts
			$panels['woocommerce']['sections']['footer_products'] = array(
				'id' => 'wpex_footer_products',
				'title' => esc_html__( 'Footer Products', 'noir' ),
				'settings' => array(
					array(
						'id' => 'footer_products_enable',
						'default' => true,
						'control' => array(
							'label' => esc_html__( 'Enable', 'noir' ),
							'type' => 'checkbox',
						),
					),
					array(
						'id' => 'footer_products_heading',
						'default' => esc_html__( 'Featured Products', 'noir' ),
						'control' => array(
							'label' => esc_html__( 'Heading', 'noir' ),
							'type' => 'text',
						),
					),
					array(
						'id' => 'footer_products_query',
						'control' => array(
							'label' => esc_html__( 'Query By', 'noir' ),
							'type' => 'select',
							'choices' => array(
								'featured' => esc_html__( 'Featured', 'noir' ),
								'latest' => esc_html__( 'Latest', 'noir' ),
								'category' => esc_html__( 'Custom Category', 'noir' ),
							),
						),
					),
					array(
						'id' => 'footer_products_query_category',
						'control' => array(
							'label' => esc_html__( 'Category', 'noir' ),
							'type' => 'select',
							'choices' => $product_categories,
							'active_callback' => 'wpex_active_callback_footer_products_query_category'
						),
					),
					array(
						'id' => 'footer_prodcuts_count',
						'default' => 4,
						'control' => array(
							'label' => esc_html__( 'Count', 'noir' ),
							'type' => 'number',
						),
					),
					array(
						'id' => 'footer_products_columns',
						'default' => 4,
						'control' => array(
							'label' => esc_html__( 'Columns', 'noir' ),
							'type' => 'select',
							'choices' => array(
								1 => 1,
								2 => 2,
								3 => 3,
								4 => 4,
							),
						),
					),
				),
			);

		}


		/*-----------------------------------------------------------------------------------*/
		/* - Typography
		/*-----------------------------------------------------------------------------------*/
		$panels['typography'] = array(
			'title' => esc_html__( 'Typography', 'noir' ),
			'sections' => array(

				// Body Typography
				array(
					'id' => 'body',
					'title' => esc_html__( 'Body', 'noir' ),
					'settings' => array(
						array(
							'id' => 'body_font_family',
							'default' => 'Libre Baskerville',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => 'body, a#cancel-comment-reply-link',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'body_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => 'body',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'body_font_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => 'body',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'body_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => 'body',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Logo Typography
				array(
					'id' => 'wpex_logo_typography',
					'title' => esc_html__( 'Logo', 'noir' ),
					'settings' => array(
						array(
							'id' => 'logo_font_family',
							'default' => 'Libre Baskerville',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-site-logo',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'logo_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-site-logo .site-text-logo',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'logo_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-site-logo .site-text-logo',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'logo_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-logo .site-text-logo',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'logo_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-logo .site-text-logo',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Subheading
				array(
					'id' => 'wpex_site_description_typography',
					'title' => esc_html__( 'Logo Subheading', 'noir' ),
					'settings' => array(
						array(
							'id' => 'site_description_font_family',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-site-description',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'site_description_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-site-description',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'site_description_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-site-description',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'site_description_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-description',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'site_description_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-description',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Menu Typography
				array(
					'id' => 'wpex_menu_typography',
					'title' => esc_html__( 'Menu', 'noir' ),
					'settings' => array(
						array(
							'id' => 'menu_font_family',
							'default' => 'Raleway',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav, .wpex-mobile-nav',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'menu_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu a',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'menu_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu a',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'menu_font_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu a',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'menu_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu a',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Mobile Menu Typography
				array(
					'id' => 'wpex_mobile_menu_typography',
					'title' => esc_html__( 'Mobile Menu', 'noir' ),
					'settings' => array(
						array(
							'id' => 'mobile_menu_font_family',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-mobile-nav',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'mobile_menu_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-mobile-nav',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'mobile_menu_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-mobile-nav',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'mobile_menu_font_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-mobile-nav',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'mobile_menu_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-mobile-nav',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Headings Typography
				array(
					'id' => 'wpex_headings_typography',
					'title' => esc_html__( 'Headings', 'noir' ),
					'desc' => 'h1,h2,h3,h4,h5,h6,thead',
					'settings' => array(
						array(
							'id' => 'headings_font_family',
							'default' => 'Raleway',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => 'h1,h2,h3,h4,h5,h6,.wpex-heading-font-family,.wpex-heading,.wpex-loop-entry-social-share-list a,.wpex-social-profiles-widget,thead, tfoot th, .cart-collaterals .cart_totals th,.woocommerce #reply-title',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'headings_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => 'h1,h2,h3,h4,h5,h6,.wpex-heading-font-family, .wpex-heading, .wpex-loop-entry-social-share-list a, .wpex-social-profiles-widget',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'headings_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => 'h1,h2,h3,h4,h5,h6,.wpex-heading-font-family, .wpex-heading, .wpex-loop-entry-social-share-list a, .wpex-social-profiles-widget',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'headings_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => 'h1,h2,h3,h4,h5,h6,.wpex-heading-font-family, .wpex-heading, .wpex-loop-entry-social-share-list a, .wpex-social-profiles-widget',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Buttons Typography
				array(
					'id' => 'wpex_buttons_typography',
					'title' => esc_html__( 'Buttons', 'noir' ),
					'settings' => array(
						array(
							'id' => 'buttons_font_family',
							'default' => 'Raleway',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.button, button, input[type="submit"], .onsale, .wpex-shop-orderby-button, .wpex-theme-button',
								'alter' => 'font-family',
								'important' => true,
							),
						),
						array(
							'id' => 'buttons_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.button, button, input[type="submit"], .onsale, .wpex-shop-orderby-button',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'buttons_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.button, button, input[type="submit"], .onsale, .wpex-shop-orderby-button',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'buttons_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.button, button, input[type="submit"], .onsale, .wpex-shop-orderby-button',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Entry Category
				array(
					'id' => 'wpex_entry_cat_typography',
					'title' => esc_html__( 'Category Tag', 'noir' ),
					'settings' => array(
						array(
							'id' => 'entry_cat_font_family',
							'default' => 'Raleway',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-entry-cat',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'entry_cat_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-entry-cat',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'entry_cat_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-entry-cat',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'entry_cat_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-entry-cat',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'entry_cat_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-entry-cat',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Entry Title Typography
				array(
					'id' => 'wpex_entry_title_typography',
					'title' => esc_html__( 'Entry Title', 'noir' ),
					'settings' => array(
						array(
							'id' => 'entry_title_font_family',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-loop-entry-title',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'entry_title_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-loop-entry-title',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'entry_title_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-loop-entry-title',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'entry_title_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-loop-entry-title',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'entry_title_color',
							'control' => array(
								'label' => esc_html__( 'Text Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-loop-entry-title a',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'entry_title_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-loop-entry-title a',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'entry_title_text_transform',
							'control' => array(
								'label' => esc_html__( 'Text Transform', 'noir' ),
								'type' => 'select',
								'choices' => array(
									'' => esc_html__( 'Default', 'noir' ),
									'none' => esc_html__( 'None', 'noir' ),
									'uppercase' => esc_html__( 'Uppercase', 'noir' ),
									'lowercase' => esc_html__( 'Lowercase', 'noir' ),
								),
							),
							'inline_css' => array(
								'target' => '.wpex-loop-entry-title a',
								'alter' => 'text-transform',
							),
						),
					),
				),

				// Post Title Typography
				array(
					'id' => 'wpex_post_title_typography',
					'title' => esc_html__( 'Post Title', 'noir' ),
					'settings' => array(
						array(
							'id' => 'post_title_font_family',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-post-title',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'post_title_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-post-title',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'post_title_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-post-title',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'post_title_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-post-title',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'post_title_color',
							'control' => array(
								'label' => esc_html__( 'Text Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-post-title',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'post_title_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-post-title',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'post_title_text_transform',
							'control' => array(
								'label' => esc_html__( 'Text Transform', 'noir' ),
								'type' => 'select',
								'choices' => array(
									'' => esc_html__( 'Default', 'noir' ),
									'none' => esc_html__( 'None', 'noir' ),
									'uppercase' => esc_html__( 'Uppercase', 'noir' ),
									'lowercase' => esc_html__( 'Lowercase', 'noir' ),
								),
							),
							'inline_css' => array(
								'target' => '.wpex-post-title',
								'alter' => 'text-transform',
							),
						),
					),
				),

				// Post Typography
				array(
					'id' => 'wpex_post_typography',
					'title' => esc_html__( 'Main Content', 'noir' ),
					'settings' => array(
						array(
							'id' => 'post_font_family',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-entry',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'post_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-entry',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'post_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-entry',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'post_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-entry',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'post_color',
							'control' => array(
								'label' => esc_html__( 'Text Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-entry',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'post_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-entry',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
					),
				),

				// Sidebar Widget Titles Typography
				array(
					'id' => 'wpex_sidebar_heading_typography',
					'title' => esc_html__( 'Sidebar Widget Titles', 'noir' ),
					'settings' => array(
						array(
							'id' => 'sidebar_heading_font_family',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget-title',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'sidebar_heading_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget-title',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'sidebar_heading_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget-title',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'sidebar_heading_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget-title',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'sidebar_heading_bg',
							'control' => array(
								'label' => esc_html__( 'Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget-title',
								'alter' => 'background-color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidebar_heading_color',
							'control' => array(
								'label' => esc_html__( 'Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget-title',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidebar_heading_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget-title',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'sidebar_heading_text_transform',
							'control' => array(
								'label' => esc_html__( 'Text Transform', 'noir' ),
								'type' => 'select',
								'choices' => array(
									'' => esc_html__( 'Default', 'noir' ),
									'none' => esc_html__( 'None', 'noir' ),
									'uppercase' => esc_html__( 'Uppercase', 'noir' ),
									'lowercase' => esc_html__( 'Lowercase', 'noir' ),
								),
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget-title',
								'alter' => 'text-transform',
							),
						),
					),
				),

				// Footer Titles Typography
				array(
					'id' => 'wpex_footer_heading_typography',
					'title' => esc_html__( 'Footer Widget Titles', 'noir' ),
					'settings' => array(
						array(
							'id' => 'footer_heading_font_family',
							'control' => array(
								'label' => esc_html__( 'Font Family', 'noir' ),
								'type' => 'google_font',
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer .widget-title',
								'alter' => 'font-family',
							),
						),
						array(
							'id' => 'footer_heading_font_weight',
							'control' => array(
								'label' => esc_html__( 'Font Weight', 'noir' ),
								'type' => 'select',
								'choices' => $font_weights,
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer .widget-title',
								'alter' => 'font-weight',
							),
						),
						array(
							'id' => 'footer_heading_font_style',
							'control' => array(
								'label' => esc_html__( 'Font Style', 'noir' ),
								'type' => 'select',
								'choices' => $font_styles,
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer .widget-title',
								'alter' => 'font-style',
							),
						),
						array(
							'id' => 'footer_heading_size',
							'control' => array(
								'label' => esc_html__( 'Font Size', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer .widget-title',
								'alter' => 'font-size',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'footer_heading_color',
							'control' => array(
								'label' => esc_html__( 'Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer .widget-title',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'footer_heading_letter_spacing',
							'control' => array(
								'label' => esc_html__( 'Letter Spacing', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer .widget-title',
								'alter' => 'letter-spacing',
								'sanitize' => 'px',
							),
						),
						array(
							'id' => 'footer_heading_text_transform',
							'control' => array(
								'label' => esc_html__( 'Text Transform', 'noir' ),
								'type' => 'select',
								'choices' => array(
									'' => esc_html__( 'Default', 'noir' ),
									'none' => esc_html__( 'None', 'noir' ),
									'uppercase' => esc_html__( 'Uppercase', 'noir' ),
									'lowercase' => esc_html__( 'Lowercase', 'noir' ),
								),
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer .widget-title a',
								'alter' => 'text-transform',
							),
						),
					),
				),

			),
		);

		/*-----------------------------------------------------------------------------------*/
		/* - Styling Panel
		/*-----------------------------------------------------------------------------------*/
		$panels['styling'] = array(
			'title' => esc_html__( 'Styling', 'noir' ),
			'sections' => array(

				// Styling > Main
				array(
					'id' => 'wpex_styling_main',
					'title' => esc_html__( 'Main', 'noir' ),
					'settings' => array(
						array(
							'id' => 'custom_accent_color',
							'control' => array(
								'label' => esc_html__( 'Accent Color', 'noir' ),
								'type' => 'color',
							),
						),
						array(
							'id' => 'body_bg',
							'control' => array(
								'label' => esc_html__( 'Body Background ', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => 'body',
								'sanitize' => 'hex',
								'alter' => 'background-color',
							),
						),
						array(
							'id' => 'link_color',
							'control' => array(
								'label' => esc_html__( 'Links', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-entry a',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
						array(
							'id' => 'link_color_hover',
							'control' => array(
								'label' => esc_html__( 'Links: Hover', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-entry a:hover',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
					),
				),

				// Styling > Topbar
				array(
					'id' => 'wpex_styling_topbar',
					'title' => esc_html__( 'Topbar', 'noir' ),
					'settings' => array(
						array(
							'id' => 'topbar_bg',
							'control' => array(
								'label' => esc_html__( 'Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-topbar-wrap',
								'alter' => 'background-color',
								'important' => true,
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'topbar_padding',
							'control' => array(
								'label' => esc_html__( 'Padding', 'noir' ),
								'type' => 'text',
								'description' => esc_html__( 'Use format: top right bottom left', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-topbar',
								'alter' => 'padding',
							),
						),
						array(
							'id' => 'topbar_color',
							'control' => array(
								'label' => esc_html__( 'Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-topbar, .wpex-has-topbar-social .wpex-topbar-ofcanvas-toggle:after, .wpex-topbar a .fa',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'topbar_link_color',
							'control' => array(
								'label' => esc_html__( 'Links', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-topbar a',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'topbar_link_color_hover',
							'control' => array(
								'label' => esc_html__( 'Links: Hover', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-topbar a:hover',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
					),
				),

				// Styling > OffCanvas Menu
				array(
					'id' => 'wpex_styling_offcanvas_menu',
					'title' => esc_html__( 'OffCanvas Menu', 'noir' ),
					'settings' => array(
						array(
							'id' => 'offcanvas_menu_bg',
							'control' => array(
								'label' => esc_html__( 'Background', 'noir' ),
								'type' => 'color',
								'active_callback' => 'wpex_active_callback_has_offcanvas_menu',
							),
							'inline_css' => array(
								'target' => '.wpex-off-canvas-menu',
								'alter' => 'background-color',
								'important' => true,
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'offcanvas_menu_link_color',
							'control' => array(
								'label' => esc_html__( 'Links', 'noir' ),
								'type' => 'color',
								'active_callback' => 'wpex_active_callback_has_offcanvas_menu',
							),
							'inline_css' => array(
								'target' => '.wpex-off-canvas-menu a',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'offcanvas_menu_link_color_hover',
							'control' => array(
								'label' => esc_html__( 'Links: Hover', 'noir' ),
								'type' => 'color',
								'active_callback' => 'wpex_active_callback_has_offcanvas_menu',
							),
							'inline_css' => array(
								'target' => '.wpex-off-canvas-menu a:hover',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
					),
				),
				
				// Styling > Header
				array(
					'id' => 'wpex_styling_header',
					'title' => esc_html__( 'Header', 'noir' ),
					'settings' => array(
						array(
							'id' => 'header_bg',
							'control' => array(
								'label' => esc_html__( 'Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-header',
								'alter' => 'background-color',
								'important' => true,
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'header_padding',
							'control' => array(
								'label' => esc_html__( 'Padding', 'noir' ),
								'type' => 'text',
								'description' => esc_html__( 'Use format: top right bottom left', 'noir' ),
							),
							'inline_css' => array(
								'target' => '.wpex-site-header',
								'alter' => 'padding',
							),
						),
						array(
							'id' => 'logo_color',
							'control' => array(
								'label' => esc_html__( 'Logo Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-logo a',
								'alter' => array(
									'color',
									'border-color',
								),
								'important' => true,
							),
						),
						array(
							'id' => 'site_description_color',
							'control' => array(
								'label' => esc_html__( 'Site Description Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-description',
								'important' => true,
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
					),
				),

				// Styling > Menu
				array(
					'id' => 'wpex_styling_nav',
					'title' => esc_html__( 'Menu', 'noir' ),
					'settings' => array(
						array(
							'id' => 'nav_bg',
							'control' => array(
								'label' => esc_html__( 'Menu Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav',
								'alter' => 'background-color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
						array(
							'id' => 'nav_border',
							'control' => array(
								'label' => esc_html__( 'Menu Border', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav',
								'alter' => 'border-color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
						array(
							'id' => 'nav_color',
							'control' => array(
								'label' => esc_html__( 'Menu Link', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu > li > a, .wpex-mobile-nav-toggle',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'nav_color_hover',
							'control' => array(
								'label' => esc_html__( 'Menu Link: Hover Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu > li > a:hover,.wpex-site-nav .wpex-dropdown-menu > li > a:hover,.wpex-site-nav .wpex-dropdown-menu > li.menu-item-has-children:hover > a,.wpex-mobile-nav-toggle:hover',
								'alter' => 'color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
						array(
							'id' => 'nav_color_hover_bg',
							'control' => array(
								'label' => esc_html__( 'Menu Link: Hover Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu > li > a:hover,.wpex-site-nav .wpex-dropdown-menu > li > a:hover,.wpex-site-nav .wpex-dropdown-menu > li.menu-item-has-children:hover > a,.wpex-mobile-nav-toggle:hover',
								'alter' => 'background-color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
						array(
							'id' => 'nav_color_active',
							'control' => array(
								'label' => esc_html__( 'Menu Link: Active Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu > li.current-menu-item > a, .wpex-site-nav .wpex-dropdown-menu > li.parent-menu-item > a, .wpex-site-nav .wpex-dropdown-menu > li.current-menu-ancestor > a, .wpex-site-nav .wpex-dropdown-menu > li > a:hover',
								'alter' => 'color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
						array(
							'id' => 'nav_color_active_bg',
							'control' => array(
								'label' => esc_html__( 'Menu Link: Active Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu > li.current-menu-item > a, .wpex-site-nav .wpex-dropdown-menu > li.parent-menu-item > a, .wpex-site-nav .wpex-dropdown-menu > li.current-menu-ancestor > a, .wpex-site-nav .wpex-dropdown-menu > li > a:hover',
								'alter' => 'background-color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
						array(
							'id' => 'nav_drop_bg',
							'control' => array(
								'label' => esc_html__( 'Menu Dropdown Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu .sub-menu',
								'alter' => 'background-color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'nav_drop_color',
							'control' => array(
								'label' => esc_html__( 'Menu Dropdown Link', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu .sub-menu a',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'nav_drop_color_hover',
							'control' => array(
								'label' => esc_html__( 'Menu Dropdown Link: Hover', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-nav .wpex-dropdown-menu .sub-menu a:hover',
								'alter' => 'color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
					),
				),

				// Mobile Menu
				array(
					'id' => 'wpex_styling_sidr',
					'title' => esc_html__( 'Mobile Menu', 'noir' ),
					'settings' => array(
						array(
							'id' => 'sidr_bg',
							'control' => array(
								'label' => esc_html__( 'Mobile Menu Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-mobile-nav-ul',
								'alter' => 'background',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidr_color',
							'control' => array(
								'label' => esc_html__( 'Mobile Menu Link', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-mobile-nav a',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidr_color_hover',
							'control' => array(
								'label' => esc_html__( 'Mobile Menu Link: Hover', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-mobile-nav a:hover',
								'alter' => 'color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
					),
				),

				// Sidebar
				array(
					'id' => 'wpex_styling_sidebar',
					'title' => esc_html__( 'Sidebar', 'noir' ),
					'settings' => array(
						array(
							'id' => 'sidebar_text_color',
							'control' => array(
								'label' => esc_html__( 'Text', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidebar_links_color',
							'control' => array(
								'label' => esc_html__( 'Links', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar-widget a',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidebar_links_hover_color',
							'control' => array(
								'label' => esc_html__( 'Links: Hover', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar-widget a:hover',
								'alter' => 'color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidebar_tags_bg',
							'control' => array(
								'label' => esc_html__( 'Tags Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget_tag_cloud a',
								'alter' => 'background-color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidebar_tags_color',
							'control' => array(
								'label' => esc_html__( 'Tags Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget_tag_cloud a',
								'alter' => 'color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
						array(
							'id' => 'sidebar_tags_bg_hover',
							'control' => array(
								'label' => esc_html__( 'Tags: Hover Background', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget_tag_cloud a:hover',
								'alter' => 'background-color',
								'sanitize' => 'hex',
							),
						),
						array(
							'id' => 'sidebar_tags_color_hover',
							'control' => array(
								'label' => esc_html__( 'Tags: Hover Color', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-sidebar .widget_tag_cloud a:hover',
								'alter' => 'color',
								'sanitize' => 'hex',
								'important' => true,
							),
						),
					),
				),

				// Footer
				array(
					'id' => 'wpex_styling_footer',
					'title' => esc_html__( 'Footer', 'noir' ),
					'settings' => array(
						array(
							'id' => 'footer_bg',
							'control' => array(
								'label' => esc_html__( 'Background ', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer',
								'sanitize' => 'hex',
								'alter' => 'background-color',
							),
						),
						array(
							'id' => 'footer_color',
							'control' => array(
								'label' => esc_html__( 'Color ', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
						array(
							'id' => 'footer_widget_title_color',
							'control' => array(
								'label' => esc_html__( 'Widget Titles', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-footer-widgets .widget-title',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
						array(
							'id' => 'footer_link',
							'control' => array(
								'label' => esc_html__( 'Links', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-footer-widgets a, .wpex-footer-widgets .widget-recent-list .wpex-title a',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
						array(
							'id' => 'footer_link_hover',
							'control' => array(
								'label' => esc_html__( 'Links: Hover ', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-site-footer a:hover, .wpex-footer-widgets .widget-recent-list .wpex-title a:hover',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
					),
				),

				// Footer Bottom
				array(
					'id' => 'wpex_styling_footer_bottom_bottom',
					'title' => esc_html__( 'Footer Bottom', 'noir' ),
					'settings' => array(
						array(
							'id' => 'footer_bottom_bg',
							'control' => array(
								'label' => esc_html__( 'Background ', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-footer-bottom',
								'sanitize' => 'hex',
								'alter' => 'background-color',
							),
						),
						array(
							'id' => 'footer_bottom_border',
							'control' => array(
								'label' => esc_html__( 'Border ', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-footer-bottom',
								'sanitize' => 'hex',
								'alter' => 'border-top-color',
							),
						),
						array(
							'id' => 'footer_bottom_color',
							'control' => array(
								'label' => esc_html__( 'Color ', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-footer-bottom',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
						array(
							'id' => 'footer_bottom_link',
							'control' => array(
								'label' => esc_html__( 'Links', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-footer-bottom a',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
						array(
							'id' => 'footer_bottom_link_hover',
							'control' => array(
								'label' => esc_html__( 'Links: Hover ', 'noir' ),
								'type' => 'color',
							),
							'inline_css' => array(
								'target' => '.wpex-footer-bottom a:hover',
								'sanitize' => 'hex',
								'alter' => 'color',
							),
						),
					),
				),

			),
		);

		/*-----------------------------------------------------------------------------------*/
		/* - Image Sizes
		/*-----------------------------------------------------------------------------------*/
		$panels['image_sizes'] = array(
			'title' => esc_html__( 'Image Sizes', 'noir' ),
			'sections' => array(

				// Left/Right Entries
				array(
					'id' => 'wpex_entry_left_right_thumbnail_sizes',
					'title' => esc_html__( 'Left/Right Entries', 'noir' ),
					'desc' => esc_html__( 'If you alter any image sizes you will have to regenerate your thumbnails.', 'noir' ),
					'settings' => array(
						array(
							'id' => 'entry_left_right_thumbnail_width',
							'default' => '500',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Width', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'entry_left_right_thumbnail_height',
							'default' => '600',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Height', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'entry_left_right_thumbnail_crop',
							'default' => 'center-center',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Crop', 'noir' ),
								'type' => 'select',
								'choices' => wpex_image_crop_locations(),
							),
						),
					),
				),

				// Full Entries
				array(
					'id' => 'wpex_entry_full_thumbnail_sizes',
					'title' => esc_html__( 'Full Entries', 'noir' ),
					'desc' => esc_html__( 'If you alter any image sizes you will have to regenerate your thumbnails.', 'noir' ),
					'settings' => array(
						array(
							'id' => 'entry_thumbnail_width',
							'default' => '700',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Width', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'entry_thumbnail_height',
							'default' => '350',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Height', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'entry_thumbnail_crop',
							'default' => 'center-center',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Crop', 'noir' ),
								'type' => 'select',
								'choices' => wpex_image_crop_locations(),
							),
						),
					),
				),

				// Grid Entries
				array(
					'id' => 'wpex_entry_grid_thumbnail_sizes',
					'title' => esc_html__( 'Grid Entries', 'noir' ),
					'desc' => esc_html__( 'If you alter any image sizes you will have to regenerate your thumbnails.', 'noir' ),
					'settings' => array(
						array(
							'id' => 'entry_grid_thumbnail_width',
							'default' => '700',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Width', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'entry_grid_thumbnail_height',
							'default' => '350',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Height', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'entry_grid_thumbnail_crop',
							'default' => 'center-center',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Crop', 'noir' ),
								'type' => 'select',
								'choices' => wpex_image_crop_locations(),
							),
						),
					),
				),

				// Featured Entry
				array(
					'id' => 'wpex_featured_entry_thumbnail_sizes',
					'title' => esc_html__( 'Featured Entry', 'noir' ),
					'desc' => esc_html__( 'If you alter any image sizes you will have to regenerate your thumbnails.', 'noir' ),
					'settings' => array(
						array(
							'id' => 'entry_featured_thumbnail_width',
							'default' => '1050',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Width', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'entry_featured_thumbnail_height',
							'default' => '540',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Height', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'entry_featured_thumbnail_crop',
							'default' => 'center-center',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Crop', 'noir' ),
								'type' => 'select',
								'choices' => wpex_image_crop_locations(),
							),
						),
					),
				),

				// Posts
				array(
					'id' => 'wpex_post_thumbnail_sizes',
					'title' => esc_html__( 'Posts', 'noir' ),
					'desc' => esc_html__( 'If you alter any image sizes you will have to regenerate your thumbnails.', 'noir' ),
					'settings' => array(
						array(
							'id' => 'post_thumbnail_width',
							'default' => '1050',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Width', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'post_thumbnail_height',
							'default' => '540',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Height', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'post_thumbnail_crop',
							'default' => 'center-center',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Crop', 'noir' ),
								'type' => 'select',
								'choices' => wpex_image_crop_locations(),
							),
						),
					),
				),

				// Related Posts
				array(
					'id' => 'wpex_posts_related_thumbnail_sizes',
					'title' => esc_html__( 'Related Posts', 'noir' ),
					'desc' => esc_html__( 'If you alter any image sizes you will have to regenerate your thumbnails.', 'noir' ),
					'settings' => array(
						array(
							'id' => 'post_related_thumbnail_width',
							'default' => '700',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Width', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'post_related_thumbnail_height',
							'default' => '350',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Height', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'post_related_thumbnail_crop',
							'default' => 'center-center',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Crop', 'noir' ),
								'type' => 'select',
								'choices' => wpex_image_crop_locations(),
							),
						),
					),
				),

				// Footer Trending
				array(
					'id' => 'footer_loop_thumbnail_width',
					'title' => esc_html__( 'Footer Posts', 'noir' ),
					'desc' => esc_html__( 'If you alter any image sizes you will have to regenerate your thumbnails.', 'noir' ),
					'settings' => array(
						array(
							'id' => 'footer_loop_thumbnail_width',
							'default' => '700',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Width', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'footer_loop_thumbnail_height',
							'default' => '350',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Image Height', 'noir' ),
								'type' => 'text',
							),
						),
						array(
							'id' => 'footer_loop_thumbnail_crop',
							'default' => 'center-center',
							'transport' => 'postMessage',
							'control' => array(
								'label' => esc_html__( 'Crop', 'noir' ),
								'type' => 'select',
								'choices' => wpex_image_crop_locations(),
							),
						),
					),
				),

			),
		);

		// Return panels array
		return $panels;

	}
}
add_filter( 'wpex_customizer_panels', 'wpex_customizer_config' );

// Callback functions
function wpex_active_callback_has_grid() {
	if ( 'grid' == get_theme_mod( 'entry_style' ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_active_callback_home_has_grid() {
	if ( 'grid' == get_theme_mod( 'home_entry_style' ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_active_callback_footer_posts_query_category() {
	if ( 'category' == get_theme_mod( 'footer_posts_query' ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_active_callback_topbar_social() {
	if ( get_theme_mod( 'topbar_social_enable', true ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_active_callback_footer_products_query_category() {
	if ( 'category' == get_theme_mod( 'footer_products_query' ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_active_callback_has_offcanvas_menu() {
	if ( has_nav_menu( 'off_canvas' ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_customizer_has_related_posts() {
	if ( get_theme_mod( 'post_related', true ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_customizer_post_navigation_in_same_term() {
	if ( get_theme_mod( 'post_next_prev', true ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_customizer_entry_has_meta() {
	if ( get_theme_mod( 'entry_meta', true ) ) {
		return true;
	} else {
		return false;
	}
}
function wpex_customizer_post_has_meta() {
	if ( get_theme_mod( 'post_meta', true ) ) {
		return true;
	} else {
		return false;
	}
}