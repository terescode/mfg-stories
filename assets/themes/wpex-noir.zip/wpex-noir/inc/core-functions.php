<?php
/**
 * Core functions used for the theme
 *
 * @package   Noir WordPress Theme
 * @author    Alexander Clarke
 * @copyright Copyright (c) 2015, WPExplorer.com
 * @link      http://www.wpexplorer.com
 * @since     1.0.0
 */

/**
 * Returns theme mod
 *
 * @since 1.0.0
 */
function wpex_get_theme_mod( $key, $default = null ) {
	if ( ! empty( $_GET[$key] ) ) {
		return ( 'false' == $_GET[$key] ) ? false : esc_html( $_GET[$key] );
	} else {
		return get_theme_mod( $key, $default );
	}
}

/**
 * Echos theme mod
 *
 * @since 1.0.0
 */
function wpex_theme_mod( $key, $default = null ) {
	echo wpex_get_theme_mod( $key, $default );
}

/**
 * Returns correct ID for any object
 * Used to fix issues with translation plugins such as WPML
 *
 * @since 3.1.1
 */
function wpex_parse_obj_id( $id = '', $type = 'page' ) {
	if ( $id && function_exists( 'icl_object_id' ) ) {
		$id = icl_object_id( $id, $type );
	}
	return $id;
}

/**
 * Array of image crop locations
 *
 * @link 2.0.0
 */
function wpex_image_crop_locations() {
	return array(
		' '             => esc_html__( 'Default', 'noir' ),
		'left-top'      => esc_html__( 'Top Left', 'noir' ),
		'right-top'     => esc_html__( 'Top Right', 'noir' ),
		'center-top'    => esc_html__( 'Top Center', 'noir' ),
		'left-center'   => esc_html__( 'Center Left', 'noir' ),
		'right-center'  => esc_html__( 'Center Right', 'noir' ),
		'center-center' => esc_html__( 'Center Center', 'noir' ),
		'left-bottom'   => esc_html__( 'Bottom Left', 'noir' ),
		'right-bottom'  => esc_html__( 'Bottom Right', 'noir' ),
		'center-bottom' => esc_html__( 'Bottom Center', 'noir' ),
	);
}

/**
 * Parse image crop option and returns correct value for add_image_size
 *
 * @link 2.0.0
 */
function wpex_parse_image_crop( $crop = 'true' ) {
	$return = true;
	if ( $crop && is_string( $crop ) && array_key_exists( $crop, wpex_image_crop_locations() ) ) {
		$return = explode( '-', $crop );
	}
	$return = $return ? $return : true;
	return $return;
}

/**
 * Get first post with featured image in current query
 *
 * @since 1.0.0
 */
function wpex_get_first_post_with_thumb( $query = '' ) {
	if ( ! $query ) {
		global $wp_query;
		$query = $wp_query;
	}
	$posts = $query->posts;
	$posts_count = count( $posts );
	if ( $posts_count == 0 ) {
		return;
	}
	$post_with_thumb = 0;
	foreach ( $posts as $post ) {
		if ( has_post_thumbnail( $post->ID ) ) {
			$post_with_thumb = $post->ID;
			break;
		}
	}
	return $post_with_thumb;
}

/**
 * Returns correct header logo src
 *
 * @since 1.0.0
 */
function wpex_get_header_logo_src() {
	$src = wpex_get_theme_mod( 'logo' );
	$src = apply_filters( 'wpex_header_logo_src', $src );
	$src = esc_url( $src );
	return $src;
}

/**
 * Returns escaped post title
 *
 * @since 1.0.0
 */
function wpex_get_esc_title() {
	return esc_attr( the_title_attribute( 'echo=0' ) );
}

/**
 * Outputs escaped post title
 *
 * @since 1.0.0
 */
function wpex_esc_title() {
	echo wpex_get_esc_title();
}

/**
 * Returns current page or post ID
 *
 * @since 1.0.0
 */
function wpex_get_the_id() {

	// If singular get_the_ID
	if ( is_singular() ) {
		return get_the_ID();
	}

	// Get ID of WooCommerce product archive
	elseif ( is_post_type_archive( 'product' ) && class_exists( 'Woocommerce' ) && function_exists( 'wc_get_page_id' ) ) {
		$shop_id = wc_get_page_id( 'shop' );
		if ( isset( $shop_id ) ) {
			return wc_get_page_id( 'shop' );
		}
	}

	// Posts page
	elseif ( is_home() && $page_for_posts = get_option( 'page_for_posts' ) ) {
		return $page_for_posts;
	}

	// Return nothing
	else {
		return NULL;
	}

}

/**
 * Returns entry style
 *
 * @since 1.0.0
 */
function wpex_get_blog_entry_style() {
	if ( ! empty( $_GET['entry_style'] ) ) {
		return esc_html( $_GET['entry_style'] );
	}
	if ( is_front_page() ) {
		$style = wpex_get_theme_mod( 'home_entry_style' );
	} else {
		$style = wpex_get_theme_mod( 'entry_style' );
	}
	$style = $style ? $style : 'left_right';
	return apply_filters( 'wpex_get_blog_entry_style', $style );
}

/**
 * Returns entry image size
 *
 * @since 1.0.0
 */
function wpex_get_entry_image_size() {
	$entry_style = wpex_get_blog_entry_style();
	if ( 'left_right' == $entry_style ) {
		$size = 'wpex_entry_left_right';
	} elseif ( 'wpex-grid' == $entry_style ) {
		$size = 'wpex_entry_grid';
	} else {
		$size = 'wpex_entry';
	}
	return apply_filters( 'wpex_get_entry_image_size', $size );
}

/**
 * Returns current page or post layout
 *
 * @since 1.0.0
 */
function wpex_get_loop_columns() {
	$columns = '1';
	if ( ! empty( $_GET['loop_columns'] ) ) {
		return esc_html( $_GET['loop_columns'] );
	}
	$post_id = wpex_get_the_id();
	if ( is_front_page() ) {
		$columns = wpex_get_theme_mod( 'home_entry_columns', '1' );
	} else {
		$columns = wpex_get_theme_mod( 'entry_columns', '1' );
	}
	return apply_filters( 'wpex_loop_columns', $columns );
}

/**
 * Returns current page or post layout
 *
 * @since 1.0.0
 */
function wpex_get_post_layout() {

	// Check URL
	if ( ! empty( $_GET['post_layout'] ) ) {
		return $_GET['post_layout'];
	}

	// Get post ID
	$post_id = wpex_get_the_id();

	// Set default layout
	$layout = 'right-sidebar';

	// Posts
	if ( is_page() ) {
		$layout = wpex_get_theme_mod( 'page_layout' );
	}

	// Posts
	elseif ( is_singular() ) {
		$layout = wpex_get_theme_mod( 'post_layout' );
	}

	// Full-width pages
	if ( is_404()
		|| is_page_template( 'templates/login-register.php' )
		|| is_page_template( 'templates/archives.php' )
	) {
		$layout = 'full-width';
	}

	// Homepage
	elseif ( is_home() || is_front_page() ) {
		$layout = wpex_get_theme_mod( 'home_layout' );
	}

	// Search
	elseif ( is_search() ) {
		$layout = wpex_get_theme_mod( 'search_layout' );
	}

	// Archive
	elseif ( is_archive() ) {
		$layout = wpex_get_theme_mod( 'archives_layout' );
	}

	// Apply filters
	$layout = apply_filters( 'wpex_post_layout', $layout );

	// Check meta
	if ( $meta = get_post_meta( wpex_get_the_id(), 'wpex_post_layout', true ) ) {
		$layout = $meta;
	}

	// Sanitize
	$layout = $layout ? $layout : 'right-sidebar';

	// Return layout
	return $layout;

}

/**
 * Returns target blank
 *
 * @since 1.0.0
 */
function wpex_get_target_blank( $display = false ) {
	if ( $display ) {
		return ' target="_blank"';
	}
}

/**
 * Echos target blank
 *
 * @since 1.0.0
 */
function wpex_target_blank( $display = false ) {
	echo wpex_get_target_blank( $display );
}

/**
 * Sanitizes data
 *
 * @since 1.0.0
 */
function wpex_sanitize( $data = '', $type = null ) {

	// Advertisement
	if ( 'advertisement' == $type ) {
		return $data;
	}

	// URL
	elseif ( 'url' == $type ) {
		$data = esc_url( $data );
	}

	// CSS
	elseif ( 'css' == $type ) {
		$data = $data; // nothing yet
	}

	// Image
	elseif ( 'img' == $type || 'image' == $type ) {
		$data = wp_kses( $data, array(
			'img'       => array(
				'src'   => array(),
				'alt'   => array(),
				'title' => array(),
				'data'  => array(),
				'id'    => array(),
				'class' => array(),
			),
		) );
	}

	// Link
	elseif ( 'link' == $type ) {
		$data = wp_kses( $data, array(
			'a'         => array(
				'href'  => array(),
				'title' => array(),
				'rel'   => array(),
				'class' => array(),
				'data'  => array(),
				'id'    => array(),
			),
		) );
	}

	// HTML
	elseif ( 'html' == $type ) {
		$data = htmlspecialchars_decode( wp_kses_post( $data ) );
	}

	// Videos
	elseif ( 'video' == $type || 'audio' == $type || 'embed' ) {
		$data = wp_kses( $data, array(
			'iframe' => array(
				'src'               => array(),
				'type'              => array(),
				'allowfullscreen'   => array(),
				'allowscriptaccess' => array(),
				'height'            => array(),
				'width'             => array()
			),
			'embed' => array(
				'src'               => array(),
				'type'              => array(),
				'allowfullscreen'   => array(),
				'allowscriptaccess' => array(),
				'height'            => array(),
				'width'             => array()
			),
		) );
	}

	// Apply filters and return
	return apply_filters( 'wpex_sanitize', $data );

}

/**
 * Checks a custom field value and returns the type (embed, oembed, etc )
 *
 * @since 1.0.0
 */
function wpex_check_meta_type( $value ) {
	if ( strpos( $value, 'embed' ) ) {
		return 'embed';
	} elseif ( strpos( $value, 'iframe' ) ) {
		return 'iframe';
	} else {
		return 'url';
	}
}

/**
 * Custom menu walker
 * 
 * @link  http://codex.wordpress.org/Class_Reference/Walker_Nav_Menu
 * @since 1.0.0
 */
if ( ! class_exists( 'WPEX_Dropdown_Walker_Nav_Menu' ) ) {
	class WPEX_Dropdown_Walker_Nav_Menu extends Walker_Nav_Menu {
		function display_element( $element, &$children_elements, $max_depth, $depth=0, $args, &$output ) {
			$id_field = $this->db_fields['id'];
			if ( ! empty( $children_elements[$element->$id_field] ) && ( $depth == 0 ) ) {
				$element->title .= ' <span class="fa fa-angle-down wpex-dropdown-arrow-down"></span>';
			}
			if ( ! empty( $children_elements[$element->$id_field] ) && ( $depth > 0 ) ) {
				$element->title .= ' <span class="fa fa-angle-right wpex-dropdown-arrow-side"></span>';
			}
			Walker_Nav_Menu::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
		}
	}
}

/**
 * Custom comments callback
 * 
 * @link  http://codex.wordpress.org/Function_Reference/wp_list_comments
 * @since 1.0.0
 */
if ( ! function_exists( 'wpex_comment' ) ) {
	function wpex_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;
		switch ( $comment->comment_type ) :
			case 'pingback' :
			case 'trackback' :
				// Display trackbacks differently than normal comments. ?>
				<li id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
				<p><strong><?php esc_html_e( 'Pingback:', 'noir' ); ?></strong> <?php comment_author_link(); ?></p>
			<?php
			break;
			default :
				// Proceed with normal comments. ?>
				<li id="li-comment-<?php comment_ID(); ?>">
					<div id="comment-<?php comment_ID(); ?>" <?php comment_class( 'wpex-clr' ); ?>>
						<div class="comment-author vcard">
							<?php
							// Display avatar
							$avatar_size = apply_filters( 'wpex_comments_avatar_size', 60 );
							echo get_avatar( $comment, $avatar_size ); ?>
						</div><!-- .comment-author -->
						<div class="comment-details wpex-clr">
							<header class="comment-meta">
								<cite class="fn"><?php comment_author_link(); ?></cite>
								<span class="comment-date">
								<?php
									printf( '<a href="%1$s"><time datetime="%2$s">%3$s</time></a>',
										esc_url( get_comment_link( $comment->comment_ID ) ),
										get_comment_time( 'c' ),
										sprintf( _x( '%1$s', '1: date', 'noir' ), get_comment_date() )
									); ?>
								</span><!-- .comment-date -->
							</header><!-- .comment-meta -->
							<?php if ( '0' == $comment->comment_approved ) : ?>
								<p class="comment-awaiting-moderation">
									<?php esc_html_e( 'Your comment is awaiting moderation.', 'noir' ); ?>
								</p><!-- .comment-awaiting-moderation -->
							<?php endif; ?>
							<div class="comment-content wpex-entry wpex-clr">
								<?php comment_text(); ?>
							</div><!-- .comment-content -->
							<footer class="comment-footer wpex-clr">
								<?php
								// Cancel comment link
								comment_reply_link( array_merge( $args, array(
									'reply_text'    => esc_html__( 'Reply', 'noir' ) . '',
									'depth'         => $depth,
									'max_depth'     => $args['max_depth']
								) ) ); ?>
								<?php
								// Edit comment link
								edit_comment_link( esc_html__( 'Edit', 'noir' ), '<div class="edit-comment">', '</div>' ); ?>
							</footer>
						</div><!-- .comment-details -->
					</div><!-- #comment-## -->
			<?php
			break;
		endswitch;
	}
}

/**
 * Returns correct entry excerpt length
 * 
 * @since 1.0.0
 */
function wpex_get_entry_excerpt_length() {
	if ( is_front_page() ) {
		$length = wpex_get_theme_mod( 'home_entry_excerpt_length', 30 );
	} else {
		$length = wpex_get_theme_mod( 'entry_excerpt_length', 30 );
	}
	$length = intval( $length ) ? intval( $length ) : 30;
	return $length;
}

/**
 * Custom excerpts based on wp_trim_words
 * Created for child-theming purposes
 * 
 * @link  http://codex.wordpress.org/Function_Reference/wp_trim_words
 * @since 1.0.0
 */
function wpex_excerpt( $length = 45, $readmore = false ) {

	// Get global post data
	global $post;

	// Check for custom excerpt
	if ( has_excerpt( $post->ID ) ) {
		$output = $post->post_excerpt;
	}

	// No custom excerpt...so lets generate one
	else {

		// Redmore text
		$readmore_text = get_theme_mod( 'entry_readmore_text', esc_html__( 'read more', 'noir' ) );

		// Readmore link
		$readmore_link = '<a href="'. get_permalink( $post->ID ) .'" title="'. $readmore_text .'">'. $readmore_text .'<span class="wpex-readmore-rarr">&rarr;</span></a>';

		// Check for more tag and return content if it exists
		if ( strpos( $post->post_content, '<!--more-->' ) ) {
			$output = get_the_content( '' );
		}

		// No more tag defined so generate excerpt using wp_trim_words
		else {

			// Generate excerpt
			$output = wp_trim_words( strip_shortcodes( get_the_content( $post->ID ) ), $length );

			// Add readmore to excerpt if enabled
			if ( $readmore == true ) {
				$output .= apply_filters( 'wpex_readmore_link', $readmore_link );
			}

		}

	}

	// Apply filters and echo
	echo apply_filters( 'wpex_excerpt', $output );

}

/**
 * Remove more link
 *
 * @since 1.0.0
 */
function wpex_remove_more_link( $link ) {
	return null;
}
add_filter( 'the_content_more_link', 'wpex_remove_more_link' );

/**
 * Includes correct template part
 *
 * @since 1.0.0
 */
function wpex_include_template( $template ) {

	// Return if no template is defined
	if ( ! $template ) {
		return;
	}

	// Locate template
	$template = locate_template( $template, false );

	// Load template if it exists
	if ( $template ) {
		include( $template );
	}

}

/**
 * List categories for specific taxonomy
 * 
 * @link    http://codex.wordpress.org/Function_Reference/wp_get_post_terms
 * @since   1.0.0
 */
if ( ! function_exists( 'wpex_get_post_terms' ) ) {

	function wpex_get_post_terms( $taxonomy = 'category', $first_only = false, $classes = '' ) {

		// Define return var
		$return = array();

		// Get terms
		$terms = wp_get_post_terms( get_the_ID(), $taxonomy );

		// Loop through terms and create array of links
		foreach ( $terms as $term ) {

			// Add classes
			$add_classes = 'wpex-term-'. $term->term_id;
			if ( $classes ) {
				$add_classes .= ' '. $classes;
			}
			if ( $add_classes ) {
				$add_classes = ' class="'. $add_classes .'"';
			}

			// Get permalink
			$permalink = get_term_link( $term->term_id, $taxonomy );

			// Add term to array
			$return[] = '<a href="'. esc_url( $permalink ) .'" title="'. $term->name .'"'. $add_classes .'>'. $term->name .'</a>';

		}

		// Return if no terms are found
		if ( ! $return ) {
			return;
		}

		// Return first category only
		if ( $first_only ) {
			
			$return = $return[0];

		}

		// Turn terms array into comma seperated list
		else {

			$return = implode( '', $return );

		}

		// Return or echo
		return $return;

	}

}

/**
 * Echos the wpex_list_post_terms function
 * 
 * @since 1.0.0
 */
function wpex_post_terms( $taxonomy = 'category', $first_only = false, $classes = '' ) {
	echo wpex_get_post_terms( $taxonomy, $first_only, $classes );
}

/**
 * Checks if a user has social options defined
 *
 * @since 1.0.0
 */

function wpex_author_has_social( $user_id = NULL ) {
	if ( get_the_author_meta( 'wpex_twitter', $user_id ) ) {
		return true;
	} elseif ( get_the_author_meta( 'wpex_facebook', $user_id ) ) {
		return true;
	} elseif ( get_the_author_meta( 'wpex_googleplus', $user_id ) ) {
		return true;
	} elseif ( get_the_author_meta( 'wpex_linkedin', $user_id ) ) {
		return true;
	} elseif ( get_the_author_meta( 'wpex_instagram', $user_id ) ) {
		return true;
	} elseif ( get_the_author_meta( 'wpex_pinterest', $user_id ) ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Returns correct ad region template part
 *
 * @since 1.0.0
 */
function wpex_ad_region( $location ) {
	if ( ! empty( $_GET['disable_ads'] ) ) {
		return;
	}
	$location = 'partials/ads/'. $location;
	get_template_part( $location );
}

/**
 * Returns correct ad region template part
 *
 * @since 1.0.0
 */
function wpex_fb_comments_url() {
	if ( ! empty( $_GET['theme_fb_comments'] ) ) {
		return 'http://developers.facebook.com/docs/plugins/comments/';
	} else {
		return get_permalink();
	}
}

/**
 * Returns the ID's to exclude for the homepage
 *
 * @since 1.0.0
 */
function wpex_exclude_home_ids(){

	$ids = array();

	// Build array of slider ID's
	if ( $exclude = get_theme_mod( 'home_slider_exclude_posts' ) ) {

		$content = get_theme_mod( 'home_slider_content', 'recent_posts' );
		$count   = get_theme_mod( 'home_slider_count', 4 );

		if ( $content && 'none' != $content && $count >= 1 ) {

			if ( 'recent_posts' == $content ) {

				$posts = get_posts( array(
					'post_type'      => 'post',
					'posts_per_page' => $count,
					'meta_key'       => '_thumbnail_id',
				) );

				if ( $posts ) {
					foreach( $posts as $post ) {
						$ids[] = $post->ID;
					}
				}


			} elseif ( 'none' != $content ) {

				$posts = get_posts( array(
					'post_type'      => 'post',
					'posts_per_page' => $count,
					'meta_key'       => '_thumbnail_id',
					'tax_query'      => array (
						array (
							'taxonomy' => 'category',
							'field'    => 'ID',
							'terms'    => $content,
						)
					)
				) );

				if ( $posts ) {
					foreach( $posts as $post ) {
						$ids[] = $post->ID;
					}
				}

			}

		}

	}

	$ids = apply_filters( 'wpex_exclude_home_ids', $ids );

	return $ids;
}

/**
 * Minify css
 *
 * @since 1.0.0
 */
function wpex_minify_css( $css = null ) {

	// Normalize whitespace
	$css = preg_replace( '/\s+/', ' ', $css );

	// Remove ; before }
	$css = preg_replace( '/;(?=\s*})/', '', $css );

	// Remove space after , : ; { } */ >
	$css = preg_replace( '/(,|:|;|\{|}|\*\/|>) /', '$1', $css );

	// Remove space before , ; { }
	$css = preg_replace( '/ (,|;|\{|})/', '$1', $css );

	// Strips leading 0 on decimal values (converts 0.5px into .5px)
	$css = preg_replace( '/(:| )0\.([0-9]+)(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}.${2}${3}', $css );

	// Strips units if value is 0 (converts 0px to 0)
	$css = preg_replace( '/(:| )(\.?)0(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}0', $css );

	// Return minified CSS
	return trim( $css );
	
}

/**
 * Returns thumbnail sizes
 *
 * @since 1.0.0
 * @link  http://codex.wordpress.org/Function_Reference/get_intermediate_image_sizes
 */
function wpex_get_thumbnail_sizes( $size = '' ) {

	global $_wp_additional_image_sizes;

	$sizes = array(
		'full'  => array(
		'width'  => '9999',
		'height' => '9999',
		'crop'   => 0,
		),
	);
	$get_intermediate_image_sizes = get_intermediate_image_sizes();

	// Create the full array with sizes and crop info
	foreach( $get_intermediate_image_sizes as $_size ) {

		if ( in_array( $_size, array( 'thumbnail', 'medium', 'large' ) ) ) {

			$sizes[ $_size ]['width']   = get_option( $_size . '_size_w' );
			$sizes[ $_size ]['height']  = get_option( $_size . '_size_h' );
			$sizes[ $_size ]['crop']    = (bool) get_option( $_size . '_crop' );

		} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {

			$sizes[ $_size ] = array( 
				'width'     => $_wp_additional_image_sizes[ $_size ]['width'],
				'height'    => $_wp_additional_image_sizes[ $_size ]['height'],
				'crop'      => $_wp_additional_image_sizes[ $_size ]['crop']
			);

		}

	}

	// Get only 1 size if found
	if ( $size ) {
		if ( isset( $sizes[ $size ] ) ) {
			return $sizes[ $size ];
		} else {
			return false;
		}
	}

	// Return sizes
	return $sizes;
}

/**
 * Display post date in "time ago" format
 *
 * @since   1.0.0
 * @return  array
 */ 
function wpex_time_ago( $post = '' ) {
 
	if ( ! $post ) {
		global $post;
	}
 
	$date = get_post_time( 'G', true, $post );
 
	// Array of time period chunks
	$chunks = array(
		array( 60 * 60 * 24 * 365 , esc_html__( 'year', 'noir' ), esc_html__( 'years', 'noir' ) ),
		array( 60 * 60 * 24 * 30 , esc_html__( 'month', 'noir' ), esc_html__( 'months', 'noir' ) ),
		array( 60 * 60 * 24 * 7, esc_html__( 'week', 'noir' ), esc_html__( 'weeks', 'noir' ) ),
		array( 60 * 60 * 24 , esc_html__( 'day', 'noir' ), esc_html__( 'days', 'noir' ) ),
		array( 60 * 60 , esc_html__( 'hour', 'noir' ), esc_html__( 'hours', 'noir' ) ),
		array( 60 , esc_html__( 'minute', 'noir' ), esc_html__( 'minutes', 'noir' ) ),
		array( 1, esc_html__( 'second', 'noir' ), esc_html__( 'seconds', 'noir' ) )
	);
 
	if ( ! is_numeric( $date ) ) {
		$time_chunks = explode( ':', str_replace( ' ', ':', $date ) );
		$date_chunks = explode( '-', str_replace( ' ', '-', $date ) );
		$date = gmmktime( (int)$time_chunks[1], (int)$time_chunks[2], (int)$time_chunks[3], (int)$date_chunks[1], (int)$date_chunks[2], (int)$date_chunks[0] );
	}
 
	$current_time = current_time( 'mysql', $gmt = 0 );
	$newer_date   = strtotime( $current_time );
 
	// Difference in seconds
	$since = $newer_date - $date;
 
	// Something went wrong with date calculation and we ended up with a negative date.
	if ( 0 > $since ) {
		return get_the_date();
	}
 
	/**
	 * We only want to output one chunks of time here, eg:
	 * x years
	 * xx months
	 * so there's only one bit of calculation below:
	 */
 
	//Step one: the first chunk
	for ( $i = 0, $j = count( $chunks ); $i < $j; $i++ ) {
		$seconds = $chunks[$i][0];
 
		// Finding the biggest chunk (if the chunk fits, break)
		if ( ( $count = floor( $since / $seconds ) ) != 0 )
			break;
	}
 
	// Set output var
	$output = ( 1 == $count ) ? '1 '. $chunks[$i][1] : $count . ' ' . $chunks[$i][2];
 
 
	if ( !(int)trim($output) ){
		$output = '0 ' . esc_html__( 'seconds', 'noir' );
	}
 
	$output .= ' '. esc_html__( 'ago', 'noir' );
 
	return $output;

}

/**
 * Header Social Options array
 *
 * @since 1.0.0
 */
function wpex_header_social_options_array() {
	$options = array(
		'twitter' => array(
			'label'      => 'Twitter',
			'icon_class' => 'fa fa-twitter',
		),
		'facebook' => array(
			'label'      => 'Facebook',
			'icon_class' => 'fa fa-facebook',
		),
		'googleplus' => array(
			'label'      => 'Google Plus',
			'icon_class' => 'fa fa-google-plus',
		),
		'pinterest' => array(
			'label'      => 'Pinterest',
			'icon_class' => 'fa fa-pinterest',
		),
		'dribbble' => array(
			'label'      => 'Dribbble',
			'icon_class' => 'fa fa-dribbble',
		),
		'vk' => array(
			'label'      => 'Vk',
			'icon_class' => 'fa fa-vk',
		),
		'instagram' => array(
			'label'      => 'Instagram',
			'icon_class' => 'fa fa-instagram',
		),
		'linkedin' => array(
			'label'      => 'LinkedIn',
			'icon_class' => 'fa fa-linkedin',
		),
		'tumblr' => array(
			'label'      => 'Tumblr',
			'icon_class' => 'fa fa-tumblr',
		),
		'github' => array(
			'label'      => 'Github',
			'icon_class' => 'fa fa-github-alt',
		),
		'flickr' => array(
			'label'      => 'Flickr',
			'icon_class' => 'fa fa-flickr',
		),
		'skype' => array(
			'label'      => 'Skype',
			'icon_class' => 'fa fa-skype',
		),
		'youtube' => array(
			'label'      => 'Youtube',
			'icon_class' => 'fa fa-youtube-play',
		),
		'vimeo' => array(
			'label'      => 'Vimeo',
			'icon_class' => 'fa fa-vimeo-square',
		),
		'vine' => array(
			'label'      => 'Vine',
			'icon_class' => 'fa fa-vine',
		),
		'xing' => array(
			'label'      => 'Xing',
			'icon_class' => 'fa fa-xing',
		),
		'yelp' => array(
			'label'      => 'Yelp',
			'icon_class' => 'fa fa-yelp',
		),

		'rss' => array(
			'label'      => esc_html__( 'RSS', 'noir' ),
			'icon_class' => 'fa fa-rss',
		),
		'email' => array(
			'label'      => esc_html__( 'Email', 'noir' ),
			'icon_class' => 'fa fa-envelope',
		),
	);
	$options = apply_filters( 'wpex_header_social_options_array', $options );
	return $options;
}

/**
 * Array of Font Icons for meta options
 *
 * @since 1.0.0
 * @return array
 */
function wpex_get_meta_awesome_icons() {
	$awesome_icons = wpex_get_awesome_icons();
	$return_array = array();
	foreach ( $awesome_icons as $awesome_icon ) {
		$return_array[] = array(
			'name'  => $awesome_icon,
			'value' => $awesome_icon
		);
	}
	return $return_array;
}

/**
 * Woo Cart count;
 *
 * @since 1.0.0
 * @return array
 */
function wpex_woocommerce_cart_count_link() {

	// Vars
	global $woocommerce;
	$cart_id = wc_get_page_id( 'cart' );
	if ( function_exists( 'icl_object_id' ) ) {
		$cart_id = icl_object_id( $cart_id, 'page' ); // WPML fix
	}
	$url = get_permalink( $cart_id );
	
	// Cart total
	$count = WC()->cart->cart_contents_count;
	if ( $count == 1 ) {
		$count = intval( $count ) .' '. esc_html__( 'Item in cart', 'noir' );
	} else {
		$count = intval( $count ) .' '. esc_html__( 'Items in cart', 'noir' );
	}

	ob_start(); ?>

		<a href="<?php echo esc_url( $url ); ?>" title="<?php esc_html_e( 'Your Cart','noir' ); ?>" class="wpex-woo-cart-fragment"><span class="fa fa-shopping-cart"></span><span class="wpex-cart-count"><?php echo $count; // sanitized above ?></span></a>
		
	<?php
	return ob_get_clean();
}

/**
 * Displays stars for rating value
 *
 * @since 1.0.0
 * @return array
 */
function wpex_star_rating( $rating = '' ) {

	// Get Meta
	if ( ! $rating ) {
		$rating = get_post_meta( $post_id, 'wpex_post_rating', true );
	}

	// Return if no rating
	if ( ! $rating ) {
		return false;
	}

	// Sanitize
	else {
		$rating = abs( $rating );
	}

	$output = '';

	// Star fonts
	$full_star  = '<span class="fa fa-star"></span>';
	$half_star  = '<span class="fa fa-star-half-full"></span>';
	$empty_star = '<span class="fa fa-star-o"></span>';

	// Integers
	if ( ( is_numeric( $rating ) && ( intval( $rating ) == floatval( $rating ) ) ) ) {
		$output = str_repeat( $full_star, $rating );
		if ( $rating < 5 ) {
			$output .= str_repeat( $empty_star, 5 - $rating );
		}
		
	// Fractions
	} else {
		$rating = intval( $rating );
		$output = str_repeat( $full_star, $rating );
		$output .= $half_star;
		if ( $rating < 5 ) {
			$output .= str_repeat( $empty_star, 4 - $rating );
		}
	}

	// Return output
	return $output;

}