<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	return -1;
}
