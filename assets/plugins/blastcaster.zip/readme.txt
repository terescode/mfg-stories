=== blastcaster ===
Contributors: terescode
Tags: blastcaster, blast, caster, terescode
Tested up to: 4.6.1
License: GPLv2 or later

Keep all your content marketing streams relevant by quickly and easily create engaging posts for content you\'ve curated

== Description ==
Keep all your content marketing streams relevant by quickly and easily create engaging posts for content you\'ve curated

== Installation ==

Upload the BlastCaster plugin to your blog and activate it.

== Changelog ==

= 1.0 =
*Not yet*

Initial version.